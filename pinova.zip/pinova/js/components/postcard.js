// ============================================================
// PINOVA — Componente: Tarjeta de publicación (masonry)
// ============================================================

function renderPostCardSkeleton(heightPx) {
  const card = el('div', { class: 'pn-card pn-card-skeleton' });
  card.style.height = heightPx + 'px';
  return card;
}

function renderPostCard(post) {
  const card = el('a', {
    class: 'pn-card',
    href: `#/post/${post.id}`,
  });

  const imgWrap = el('div', { class: 'pn-card-img-wrap' });
  const img = el('img', {
    class: 'pn-card-img',
    src: post.image_url,
    alt: post.title || '',
    loading: 'lazy',
  });
  imgWrap.appendChild(img);

  const overlay = el('div', { class: 'pn-card-overlay' });

  const saveBtn = el('button', {
    class: 'pn-card-save-btn',
    onClick: async (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!PinovaAuth.requireAuth()) return;
      const saved = saveBtn.dataset.saved === 'true';
      saveBtn.disabled = true;
      try {
        const nowSaved = await InteractionsService.toggleSave(PinovaAuth.user.id, post.id, saved);
        saveBtn.dataset.saved = String(nowSaved);
        saveBtn.classList.toggle('pn-saved', nowSaved);
        saveBtn.innerHTML = '';
        saveBtn.appendChild(icon(nowSaved ? 'bookmark-check' : 'bookmark', 16));
        saveBtn.append(nowSaved ? ' Guardado' : ' Guardar');
        toast(nowSaved ? 'Publicación guardada' : 'Se quitó de guardados', 'success');
      } catch (err) {
        toast('No se pudo guardar. Intenta de nuevo.', 'error');
      } finally {
        saveBtn.disabled = false;
      }
    },
  });
  saveBtn.dataset.saved = 'false';
  saveBtn.appendChild(icon('bookmark', 16));
  saveBtn.append(' Guardar');

  const menuBtn = el('button', {
    class: 'pn-card-menu-btn',
    onClick: (e) => { e.preventDefault(); e.stopPropagation(); showPostMenu(post, menuBtn); },
  }, icon('more-horizontal', 16));

  const externalBtn = post.external_link ? el('a', {
    class: 'pn-card-external-btn',
    href: post.external_link,
    target: '_blank',
    rel: 'noopener noreferrer',
    onClick: (e) => e.stopPropagation(),
  }, icon('arrow-up-right', 14)) : null;

  overlay.append(saveBtn, menuBtn);
  if (externalBtn) overlay.appendChild(externalBtn);
  imgWrap.appendChild(overlay);

  const meta = el('div', { class: 'pn-card-meta' }, [
    el('p', { class: 'pn-card-title' }, post.title),
    el('div', { class: 'pn-card-footer' }, [
      el('div', { class: 'pn-card-author' }, [
        renderAvatar(post.author, 22),
        el('span', {}, post.author?.display_name || 'Anónimo'),
      ]),
      el('div', { class: 'pn-card-saves' }, [
        icon('bookmark', 13),
        el('span', {}, formatCount(post.save_count || 0)),
      ]),
    ]),
  ]);

  card.append(imgWrap, meta);
  attachLongPress(card, post);

  // marcar estado guardado real de forma asíncrona
  if (PinovaAuth.isLoggedIn()) {
    InteractionsService.isSaved(PinovaAuth.user.id, post.id).then(saved => {
      if (saved) {
        saveBtn.dataset.saved = 'true';
        saveBtn.classList.add('pn-saved');
        saveBtn.innerHTML = '';
        saveBtn.appendChild(icon('bookmark-check', 16));
        saveBtn.append(' Guardado');
      }
    });
  }

  return card;
}

function renderAvatar(profile, size = 32) {
  if (profile?.avatar_url) {
    return el('img', {
      class: 'pn-avatar',
      src: profile.avatar_url,
      alt: profile.display_name || '',
      style: `width:${size}px;height:${size}px;`,
    });
  }
  const div = el('div', {
    class: 'pn-avatar pn-avatar-fallback',
    style: `width:${size}px;height:${size}px;font-size:${Math.round(size * 0.4)}px;`,
  }, initials(profile?.display_name));
  return div;
}

function showPostMenu(post, anchorBtn) {
  qsa('.pn-dropdown-menu').forEach(m => m.remove());
  const isOwner = PinovaAuth.user && PinovaAuth.user.id === post.author_id;
  const menu = el('div', { class: 'pn-dropdown-menu' });

  menu.appendChild(el('button', {
    onClick: (e) => {
      e.preventDefault(); e.stopPropagation();
      navigator.clipboard?.writeText(location.origin + location.pathname + `#/post/${post.id}`);
      toast('Enlace copiado', 'success');
      menu.remove();
    },
  }, [icon('link', 15), ' Copiar enlace']));

  menu.appendChild(el('button', {
    onClick: (e) => {
      e.preventDefault(); e.stopPropagation();
      showAddToBoardModal(post);
      menu.remove();
    },
  }, [icon('layout-grid', 15), ' Añadir a tablero']));

  menu.appendChild(el('button', {
    onClick: (e) => {
      e.preventDefault(); e.stopPropagation();
      const safeName = (post.title || 'pinova-imagen').toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 50);
      downloadImage(post.image_url, `${safeName}.jpg`);
      menu.remove();
    },
  }, [icon('download', 15), ' Descargar imagen']));

  if (isOwner) {
    menu.appendChild(el('button', {
      onClick: (e) => {
        e.preventDefault(); e.stopPropagation();
        location.hash = `#/edit/${post.id}`;
        menu.remove();
      },
    }, [icon('pencil', 15), ' Editar']));

    menu.appendChild(el('button', {
      class: 'pn-menu-danger',
      onClick: async (e) => {
        e.preventDefault(); e.stopPropagation();
        menu.remove();
        const ok = await confirmDialog({
          title: 'Eliminar publicación',
          message: 'Esta acción no se puede deshacer. La publicación se eliminará permanentemente.',
        });
        if (ok) {
          try {
            await PostsService.remove(post.id);
            toast('Publicación eliminada', 'success');
            anchorBtn.closest('.pn-card')?.remove();
          } catch {
            toast('No se pudo eliminar la publicación', 'error');
          }
        }
      },
    }, [icon('trash-2', 15), ' Eliminar']));
  }

  document.body.appendChild(menu);
  const rect = anchorBtn.getBoundingClientRect();
  menu.style.top = (rect.bottom + window.scrollY + 4) + 'px';
  menu.style.left = Math.min(rect.left + window.scrollX, window.innerWidth - 200) + 'px';

  setTimeout(() => {
    document.addEventListener('click', function closeMenu(e) {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    });
  }, 0);
}
