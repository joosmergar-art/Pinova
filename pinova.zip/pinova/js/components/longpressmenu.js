// ============================================================
// PINOVA — Menú de mantener presionado (long-press), estilo
// vista previa de Instagram: fondo oscurecido + imagen + acciones.
// ============================================================

function showLongPressMenu(post) {
  qsa('.pn-longpress-overlay').forEach(m => m.remove());

  const overlay = el('div', { class: 'pn-longpress-overlay' });

  const previewCard = el('div', { class: 'pn-longpress-preview' }, [
    el('div', { class: 'pn-longpress-preview-header' }, [
      renderAvatar(post.author, 34),
      el('div', { class: 'pn-longpress-preview-author' }, [
        el('span', {}, post.author?.display_name || 'Anónimo'),
        el('span', { class: 'pn-longpress-preview-handle' }, post.author?.username ? '@' + post.author.username : ''),
      ]),
    ]),
    el('img', { src: post.image_url, class: 'pn-longpress-preview-img', alt: post.title || '' }),
  ]);

  const actions = el('div', { class: 'pn-longpress-actions' });

  function actionRow(iconName, label, onClick, danger = false) {
    return el('button', {
      class: `pn-longpress-action-row ${danger ? 'pn-longpress-danger' : ''}`,
      onClick: (e) => { e.preventDefault(); e.stopPropagation(); onClick?.(); close(); },
    }, [icon(iconName, 22), el('span', {}, label)]);
  }

  actions.append(
    actionRow('bookmark', 'Guardar', async () => {
      if (!PinovaAuth.requireAuth()) return;
      try {
        const alreadySaved = await InteractionsService.isSaved(PinovaAuth.user.id, post.id);
        const nowSaved = await InteractionsService.toggleSave(PinovaAuth.user.id, post.id, alreadySaved);
        toast(nowSaved ? 'Publicación guardada' : 'Se quitó de guardados', 'success');
      } catch {
        toast('No se pudo guardar. Intenta de nuevo.', 'error');
      }
    }),
    actionRow('message-circle', 'Comentario', () => { location.hash = `#/post/${post.id}`; }),
    actionRow('download', 'Descargar', () => {
      const safeName = (post.title || 'pinova-imagen').toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 50);
      downloadImage(post.image_url, `${safeName}.jpg`);
    }),
    actionRow('send', 'Compartir', () => {
      navigator.clipboard?.writeText(location.origin + location.pathname + `#/post/${post.id}`);
      toast('Enlace copiado', 'success');
    }),
    actionRow('flag', 'Denunciar', () => {
      toast('Gracias, revisaremos esta publicación', 'default');
    }, true),
  );

  overlay.append(previewCard, actions);

  function close() {
    overlay.classList.remove('pn-longpress-show');
    setTimeout(() => overlay.remove(), 180);
    document.removeEventListener('click', onOutsideClick);
  }
  function onOutsideClick(e) {
    if (!previewCard.contains(e.target) && !actions.contains(e.target)) close();
  }

  document.body.appendChild(overlay);
  requestAnimationFrame(() => overlay.classList.add('pn-longpress-show'));
  setTimeout(() => document.addEventListener('click', onOutsideClick), 50);
}

/**
 * Añade el gesto de "mantener presionado" a un elemento (tarjeta de post),
 * mostrando el menú tipo Instagram tras ~450ms de presión sostenida.
 * Funciona tanto con touch como con mouse (para pruebas en escritorio).
 */
function attachLongPress(targetEl, post) {
  let timer = null;
  let triggered = false;
  let startX = 0, startY = 0;
  const THRESHOLD_MS = 450;
  const MOVE_TOLERANCE = 10;

  function start(x, y) {
    triggered = false;
    startX = x; startY = y;
    timer = setTimeout(() => {
      triggered = true;
      if (navigator.vibrate) navigator.vibrate(12);
      showLongPressMenu(post);
    }, THRESHOLD_MS);
  }
  function cancel() {
    clearTimeout(timer);
  }
  function move(x, y) {
    if (Math.abs(x - startX) > MOVE_TOLERANCE || Math.abs(y - startY) > MOVE_TOLERANCE) cancel();
  }

  targetEl.addEventListener('touchstart', (e) => {
    const t = e.touches[0];
    start(t.clientX, t.clientY);
  }, { passive: true });
  targetEl.addEventListener('touchmove', (e) => {
    const t = e.touches[0];
    move(t.clientX, t.clientY);
  }, { passive: true });
  targetEl.addEventListener('touchend', cancel);
  targetEl.addEventListener('touchcancel', cancel);

  targetEl.addEventListener('mousedown', (e) => start(e.clientX, e.clientY));
  targetEl.addEventListener('mousemove', (e) => move(e.clientX, e.clientY));
  targetEl.addEventListener('mouseup', cancel);
  targetEl.addEventListener('mouseleave', cancel);

  // Si se disparó el long-press, evita que el click/navegación normal se ejecute justo después.
  targetEl.addEventListener('click', (e) => {
    if (triggered) { e.preventDefault(); e.stopPropagation(); triggered = false; }
  }, true);
}
