// ============================================================
// PINOVA — Modal: añadir publicación a un tablero
// ============================================================

async function showAddToBoardModal(post) {
  if (!PinovaAuth.requireAuth()) return;

  const overlay = el('div', { class: 'pn-modal-overlay' });
  const box = el('div', { class: 'pn-modal-box' }, [
    el('div', { class: 'pn-modal-header' }, [
      el('h3', {}, 'Guardar en tablero'),
      el('button', { class: 'pn-modal-close', onClick: () => overlay.remove() }, icon('x', 18)),
    ]),
  ]);

  const listWrap = el('div', { class: 'pn-board-list' }, [
    el('div', { class: 'pn-spinner-wrap' }, el('div', { class: 'pn-spinner' })),
  ]);
  box.appendChild(listWrap);

  const newBoardForm = el('form', { class: 'pn-new-board-form' }, [
    el('input', { type: 'text', placeholder: 'Nombre del nuevo tablero', class: 'pn-input', required: 'true', maxlength: '60' }),
    el('button', { type: 'submit', class: 'pn-btn pn-btn-primary' }, 'Crear'),
  ]);
  newBoardForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const input = newBoardForm.querySelector('input');
    const name = input.value.trim();
    if (!name) return;
    try {
      const board = await BoardsService.create({ ownerId: PinovaAuth.user.id, name, description: '', isPublic: true });
      await BoardsService.addPost(board.id, post.id, post.image_url);
      toast(`Guardado en "${name}"`, 'success');
      overlay.remove();
    } catch {
      toast('No se pudo crear el tablero', 'error');
    }
  });
  box.appendChild(newBoardForm);

  overlay.appendChild(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);

  try {
    const boards = await BoardsService.fetchByOwner(PinovaAuth.user.id, true);
    listWrap.innerHTML = '';
    if (boards.length === 0) {
      listWrap.appendChild(el('p', { class: 'pn-muted' }, 'Aún no tienes tableros. Crea el primero abajo.'));
    }
    boards.forEach(board => {
      const row = el('button', { class: 'pn-board-row' }, [
        board.cover_url
          ? el('img', { src: board.cover_url, class: 'pn-board-row-cover' })
          : el('div', { class: 'pn-board-row-cover pn-board-row-cover-empty' }, icon('image', 18)),
        el('div', { class: 'pn-board-row-info' }, [
          el('span', { class: 'pn-board-row-name' }, board.name),
          el('span', { class: 'pn-board-row-count' }, `${board.post_count} publicaciones`),
        ]),
      ]);
      row.addEventListener('click', async () => {
        try {
          await BoardsService.addPost(board.id, post.id, post.image_url);
          toast(`Guardado en "${board.name}"`, 'success');
          overlay.remove();
        } catch {
          toast('No se pudo guardar en el tablero', 'error');
        }
      });
      listWrap.appendChild(row);
    });
  } catch {
    listWrap.innerHTML = '';
    listWrap.appendChild(el('p', { class: 'pn-muted' }, 'No se pudieron cargar tus tableros.'));
  }
}
