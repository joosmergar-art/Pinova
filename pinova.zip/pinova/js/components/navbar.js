// ============================================================
// PINOVA — Navbar superior + navegación inferior móvil
// ============================================================

function renderNavbar() {
  const nav = el('nav', { class: 'pn-navbar' });

  const logo = el('a', { href: '#/', class: 'pn-logo' }, [
    el('span', { class: 'pn-logo-mark' }, '◆'),
    el('span', { class: 'pn-logo-text' }, 'Pinova'),
  ]);

  const links = el('div', { class: 'pn-navbar-links' }, [
    el('a', { href: '#/', class: 'pn-nav-link' }, 'Inicio'),
    el('a', { href: '#/explore', class: 'pn-nav-link' }, 'Explorar'),
  ]);

  const searchForm = el('form', { class: 'pn-navbar-search' });
  const searchInput = el('input', {
    type: 'text',
    placeholder: 'Buscar imágenes, temas o personas',
    class: 'pn-search-input',
  });
  const cameraBtn = el('button', {
    type: 'button', class: 'pn-navbar-camera-btn',
    onClick: (e) => { e.preventDefault(); showVisualSearchModal(); },
  }, icon('camera', 17));
  searchForm.append(icon('search', 18), searchInput, cameraBtn);
  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const term = searchInput.value.trim();
    if (term) PinovaRouter.navigate(`/search?q=${encodeURIComponent(term)}`);
  });

  const actions = el('div', { class: 'pn-navbar-actions' });

  const createBtn = el('a', { href: '#/create', class: 'pn-btn pn-btn-primary pn-btn-create' }, [
    icon('plus', 16), el('span', {}, 'Crear'),
  ]);
  actions.appendChild(createBtn);

  const notifWrap = el('div', { class: 'pn-notif-wrap' });
  const notifBtn = el('button', { class: 'pn-icon-btn', onClick: () => toggleNotifPanel(notifWrap) }, icon('bell', 20));
  const notifBadge = el('span', { class: 'pn-notif-badge pn-hidden' });
  notifWrap.append(notifBtn, notifBadge);
  actions.appendChild(notifWrap);

  const avatarLink = el('a', { href: '#/profile/me', class: 'pn-navbar-avatar' });
  actions.appendChild(avatarLink);

  nav.append(logo, links, searchForm, actions);

  function paintAuthState(user, profile) {
    avatarLink.innerHTML = '';
    if (user) {
      avatarLink.appendChild(renderAvatar(profile, 30));
      avatarLink.setAttribute('href', `#/profile/${profile?.username || 'me'}`);
      notifWrap.classList.remove('pn-hidden');
      refreshUnreadBadge(notifBadge);
    } else {
      avatarLink.setAttribute('href', '#/login');
      avatarLink.appendChild(el('div', { class: 'pn-avatar pn-avatar-fallback' }, icon('user', 15)));
      notifWrap.classList.add('pn-hidden');
    }
  }
  PinovaAuth.onChange(paintAuthState);
  paintAuthState(PinovaAuth.user, PinovaAuth.profile);

  return nav;
}

async function refreshUnreadBadge(badgeEl) {
  if (!PinovaAuth.isLoggedIn()) return;
  try {
    const count = await NotificationsService.unreadCount(PinovaAuth.user.id);
    if (count > 0) {
      badgeEl.textContent = count > 9 ? '9+' : String(count);
      badgeEl.classList.remove('pn-hidden');
    } else {
      badgeEl.classList.add('pn-hidden');
    }
  } catch { /* silencioso */ }
}

async function toggleNotifPanel(anchorWrap) {
  qsa('.pn-notif-panel').forEach(p => p.remove());
  if (!PinovaAuth.requireAuth()) return;

  const panel = el('div', { class: 'pn-notif-panel' }, [
    el('div', { class: 'pn-notif-panel-header' }, [
      el('span', {}, 'Notificaciones'),
    ]),
    el('div', { class: 'pn-spinner-wrap' }, el('div', { class: 'pn-spinner' })),
  ]);
  anchorWrap.appendChild(panel);

  setTimeout(() => {
    document.addEventListener('click', function close(e) {
      if (!panel.contains(e.target) && !anchorWrap.contains(e.target)) {
        panel.remove();
        document.removeEventListener('click', close);
      } else if (panel.contains(e.target)) {
        // keep open on internal clicks except links
      }
    });
  }, 0);

  try {
    const items = await NotificationsService.fetch(PinovaAuth.user.id);
    const body = panel.querySelector('.pn-spinner-wrap');
    body.remove();
    if (items.length === 0) {
      panel.appendChild(el('p', { class: 'pn-muted pn-notif-empty' }, 'No tienes notificaciones aún.'));
    } else {
      const list = el('div', { class: 'pn-notif-list' });
      items.forEach(n => list.appendChild(renderNotificationRow(n)));
      panel.appendChild(list);
    }
    await NotificationsService.markAllRead(PinovaAuth.user.id);
    qs('.pn-notif-badge').classList.add('pn-hidden');
  } catch {
    panel.appendChild(el('p', { class: 'pn-muted pn-notif-empty' }, 'No se pudieron cargar las notificaciones.'));
  }
}

function renderNotificationRow(n) {
  const verbs = { like: 'le gustó', save: 'guardó', comment: 'comentó en', follow: 'comenzó a seguirte' };
  const text = n.type === 'follow' ? `${n.actor?.display_name || 'Alguien'} ${verbs.follow}` : `${n.actor?.display_name || 'Alguien'} ${verbs[n.type]} tu publicación`;
  const row = el('a', {
    class: 'pn-notif-row',
    href: n.type === 'follow' ? `#/profile/${n.actor?.username}` : `#/post/${n.post_id}`,
  }, [
    renderAvatar(n.actor, 32),
    el('div', { class: 'pn-notif-row-text' }, [
      el('span', {}, text),
      el('span', { class: 'pn-notif-row-time' }, timeAgo(n.created_at)),
    ]),
    n.post?.image_url ? el('img', { class: 'pn-notif-row-thumb', src: n.post.image_url }) : null,
  ]);
  return row;
}

function renderBottomNav() {
  const nav = el('div', { class: 'pn-bottom-nav' });
  const items = [
    { href: '#/', label: 'Inicio', iconName: 'home' },
    { href: '#/explore', label: 'Explorar', iconName: 'compass' },
    { href: '#/create', label: 'Crear', iconName: 'plus-square' },
    { href: '#/saved', label: 'Guardados', iconName: 'bookmark' },
    { href: '#/profile/me', label: 'Perfil', iconName: 'user' },
  ];
  items.forEach(item => {
    const link = el('a', { href: item.href, class: 'pn-bottom-nav-item' }, [
      icon(item.iconName, 22),
      el('span', {}, item.label),
    ]);
    nav.appendChild(link);
  });
  return nav;
}

function updateActiveNav() {
  const path = location.hash.slice(1).split('?')[0] || '/';
  qsa('.pn-nav-link, .pn-bottom-nav-item').forEach(a => {
    const href = a.getAttribute('href').slice(1);
    a.classList.toggle('pn-active', href === path || (href === '/' && path === '/'));
  });
}
window.addEventListener('hashchange', updateActiveNav);
