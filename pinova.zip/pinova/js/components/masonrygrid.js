// ============================================================
// PINOVA — Grid masonry con carga progresiva e infinite scroll
// ============================================================

function createMasonryGrid({ container, fetchPage, emptyMessage = 'No hay nada por aquí todavía.', emptyIcon = 'image-off' }) {
  const grid = el('div', { class: 'pn-masonry' });
  container.appendChild(grid);

  let page = 0;
  let loading = false;
  let exhausted = false;
  let sentinel = null;

  function appendSkeletons(n = 8) {
    const heights = [220, 280, 340, 260, 300, 240, 320, 260];
    for (let i = 0; i < n; i++) {
      grid.appendChild(renderPostCardSkeleton(heights[i % heights.length]));
    }
  }

  function clearSkeletons() {
    qsa('.pn-card-skeleton', grid).forEach(s => s.remove());
  }

  async function loadNext() {
    if (loading || exhausted) return;
    loading = true;
    appendSkeletons(6);
    try {
      const items = await fetchPage(page);
      clearSkeletons();
      if (!items || items.length === 0) {
        exhausted = true;
        if (page === 0) {
          grid.appendChild(el('div', { class: 'pn-empty-state pn-empty-inline' }, [
            icon(emptyIcon, 40),
            el('p', {}, emptyMessage),
          ]));
        }
        if (sentinel) sentinel.remove();
        return;
      }
      items.forEach((post, i) => {
        const card = renderPostCard(post);
        card.style.animationDelay = (i % 12) * 30 + 'ms';
        card.classList.add('pn-card-enter');
        grid.appendChild(card);
      });
      page += 1;
      if (items.length < PINOVA_CONFIG.postsPerPage) exhausted = true;
    } catch (err) {
      console.error('Error al cargar publicaciones:', err);
      clearSkeletons();
      grid.appendChild(el('div', { class: 'pn-empty-state pn-empty-inline' }, [
        icon('alert-triangle', 36),
        el('p', {}, 'No se pudo cargar el contenido. Desliza para reintentar.'),
      ]));
    } finally {
      loading = false;
    }
  }

  sentinel = el('div', { class: 'pn-scroll-sentinel' });
  container.appendChild(sentinel);
  const observer = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting) loadNext();
  }, { rootMargin: '600px' });
  observer.observe(sentinel);

  loadNext();

  return { grid, reload: () => { grid.innerHTML = ''; page = 0; exhausted = false; loadNext(); } };
}
