// ============================================================
// PINOVA — Modal: buscar imágenes libres de copyright (Pexels)
// ============================================================

function showStockPhotoModal(onSelect) {
  const overlay = el('div', { class: 'pn-modal-overlay' });

  const searchInput = el('input', { type: 'text', class: 'pn-input', placeholder: 'Buscar: naturaleza, ciudad, comida...' });
  const searchBtn = el('button', { type: 'submit', class: 'pn-btn pn-btn-primary' }, icon('search', 16));
  const searchForm = el('form', { class: 'pn-stock-search-form' }, [searchInput, searchBtn]);

  const resultsGrid = el('div', { class: 'pn-stock-grid' });
  const statusMsg = el('p', { class: 'pn-muted pn-stock-status' }, 'Buscando fotos destacadas...');

  const box = el('div', { class: 'pn-modal-box pn-stock-modal-box' }, [
    el('div', { class: 'pn-modal-header' }, [
      el('h3', {}, 'Imágenes sin copyright'),
      el('button', { class: 'pn-modal-close', onClick: () => overlay.remove() }, icon('x', 18)),
    ]),
    searchForm,
    statusMsg,
    resultsGrid,
    el('p', { class: 'pn-stock-credit' }, [icon('info', 12), ' Fotos cortesía de Pexels, de uso libre incluso comercial.']),
  ]);

  overlay.appendChild(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);

  async function loadResults(fetcher) {
    resultsGrid.innerHTML = '';
    statusMsg.classList.remove('pn-hidden');
    statusMsg.textContent = 'Buscando...';
    try {
      const photos = await fetcher();
      statusMsg.classList.add('pn-hidden');
      if (photos.length === 0) {
        statusMsg.classList.remove('pn-hidden');
        statusMsg.textContent = 'No encontramos fotos para esa búsqueda.';
        return;
      }
      photos.forEach(photo => {
        const tile = el('button', { type: 'button', class: 'pn-stock-tile' }, [
          el('img', { src: photo.thumbUrl, alt: photo.alt, loading: 'lazy' }),
          el('span', { class: 'pn-stock-tile-credit' }, photo.photographer),
        ]);
        tile.addEventListener('click', async () => {
          tile.classList.add('pn-stock-tile-loading');
          try {
            const file = await StockPhotosService.toFile(photo);
            onSelect(file, photo.thumbUrl);
            overlay.remove();
            toast('Imagen añadida', 'success');
          } catch {
            toast('No se pudo cargar esa imagen. Prueba con otra.', 'error');
            tile.classList.remove('pn-stock-tile-loading');
          }
        });
        resultsGrid.appendChild(tile);
      });
    } catch {
      statusMsg.classList.remove('pn-hidden');
      statusMsg.textContent = 'No se pudo conectar con el banco de imágenes. Intenta de nuevo.';
    }
  }

  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const term = searchInput.value.trim();
    if (!term) return;
    loadResults(() => StockPhotosService.search(term));
  });

  loadResults(() => StockPhotosService.curated());
}
