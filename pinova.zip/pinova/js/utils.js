// ============================================================
// PINOVA — Utilidades compartidas
// ============================================================

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') {
      node.addEventListener(k.slice(2).toLowerCase(), v);
    } else if (v !== null && v !== undefined) {
      node.setAttribute(k, v);
    }
  }
  const list = Array.isArray(children) ? children : [children];
  for (const child of list) {
    if (child === null || child === undefined) continue;
    node.append(child instanceof Node ? child : document.createTextNode(child));
  }
  return node;
}

function icon(name, size = 20) {
  const span = el('span', { class: 'pn-icon' });
  span.innerHTML = `<i data-lucide="${name}"></i>`;
  span.style.display = 'inline-flex';
  requestAnimationFrame(() => {
    if (window.lucide) window.lucide.createIcons({ nameAttr: 'data-lucide', attrs: { width: size, height: size } });
  });
  return span;
}

function refreshIcons() {
  if (window.lucide) window.lucide.createIcons();
}

function timeAgo(dateStr) {
  const date = new Date(dateStr);
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  const units = [
    ['año', 31536000], ['mes', 2592000], ['semana', 604800],
    ['día', 86400], ['hora', 3600], ['minuto', 60],
  ];
  for (const [label, secs] of units) {
    const val = Math.floor(seconds / secs);
    if (val >= 1) return `hace ${val} ${label}${val > 1 ? (label === 'mes' ? 'es' : 's') : ''}`;
  }
  return 'justo ahora';
}

function formatCount(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1).replace('.0', '') + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1).replace('.0', '') + 'k';
  return String(n);
}

function initials(name) {
  if (!name) return '?';
  return name.trim().split(/\s+/).slice(0, 2).map(w => w[0]?.toUpperCase() || '').join('');
}

// ---- Toasts ----
let toastContainer = null;
function toast(message, type = 'default') {
  if (!toastContainer) {
    toastContainer = el('div', { class: 'pn-toast-container' });
    document.body.appendChild(toastContainer);
  }
  const iconName = type === 'success' ? 'check-circle' : type === 'error' ? 'alert-circle' : 'info';
  const t = el('div', { class: `pn-toast pn-toast-${type}` }, [
    icon(iconName, 18),
    el('span', {}, message),
  ]);
  toastContainer.appendChild(t);
  requestAnimationFrame(() => t.classList.add('pn-toast-show'));
  setTimeout(() => {
    t.classList.remove('pn-toast-show');
    setTimeout(() => t.remove(), 250);
  }, 3200);
}

// ---- Confirm dialog (para acciones destructivas) ----
function confirmDialog({ title, message, confirmLabel = 'Eliminar', danger = true }) {
  return new Promise((resolve) => {
    const overlay = el('div', { class: 'pn-modal-overlay' });
    const box = el('div', { class: 'pn-confirm-box' }, [
      el('h3', {}, title),
      el('p', {}, message),
      el('div', { class: 'pn-confirm-actions' }, [
        el('button', { class: 'pn-btn pn-btn-ghost', onClick: () => { overlay.remove(); resolve(false); } }, 'Cancelar'),
        el('button', {
          class: `pn-btn ${danger ? 'pn-btn-danger' : 'pn-btn-primary'}`,
          onClick: () => { overlay.remove(); resolve(true); },
        }, confirmLabel),
      ]),
    ]);
    overlay.appendChild(box);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) { overlay.remove(); resolve(false); } });
    document.body.appendChild(overlay);
  });
}

async function downloadImage(url, filename) {
  try {
    const response = await fetch(url, { mode: 'cors' });
    const blob = await response.blob();
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename || 'pinova-imagen.jpg';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(blobUrl);
    toast('Descargando imagen...', 'success');
  } catch (err) {
    // Fallback: si el fetch falla (CORS u otro motivo), abrir la imagen en una pestaña
    // nueva para que el usuario pueda guardarla manualmente.
    window.open(url, '_blank');
    toast('Abriendo imagen para guardarla', 'default');
  }
}

function debounce(fn, wait = 300) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}

function qs(sel, root = document) { return root.querySelector(sel); }
function qsa(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }
