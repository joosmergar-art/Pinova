// ============================================================
// PINOVA — Router SPA (hash-based, sin build tooling)
// ============================================================

const PinovaRouter = {
  routes: [],
  root: null,

  init(rootEl) {
    this.root = rootEl;
    window.addEventListener('hashchange', () => this.resolve());
    window.addEventListener('DOMContentLoaded', () => this.resolve());
  },

  add(pattern, handler, { auth = false } = {}) {
    const keys = [];
    const regex = new RegExp('^' + pattern.replace(/:[^\/]+/g, (m) => {
      keys.push(m.slice(1));
      return '([^/]+)';
    }) + '$');
    this.routes.push({ regex, keys, handler, auth });
  },

  navigate(path) {
    location.hash = path;
  },

  resolve() {
    const hash = location.hash.slice(1) || '/';
    const path = hash.split('?')[0];
    const queryStr = hash.split('?')[1] || '';
    const params2 = new URLSearchParams(queryStr);

    for (const route of this.routes) {
      const match = path.match(route.regex);
      if (match) {
        if (route.auth && !PinovaAuth.isLoggedIn()) {
          toast('Inicia sesión para acceder a esta sección', 'default');
          this.navigate('/login');
          return;
        }
        const params = {};
        route.keys.forEach((key, i) => { params[key] = decodeURIComponent(match[i + 1]); });
        this.root.innerHTML = '';
        window.scrollTo(0, 0);
        route.handler(params, params2);
        return;
      }
    }
    this.root.innerHTML = '';
    renderNotFound(this.root);
  },
};

function renderNotFound(root) {
  root.appendChild(el('div', { class: 'pn-empty-state pn-page-pad' }, [
    icon('compass', 48),
    el('h2', {}, 'Página no encontrada'),
    el('p', {}, 'Este contenido no existe o fue movido.'),
    el('button', { class: 'pn-btn pn-btn-primary', onClick: () => PinovaRouter.navigate('/') }, 'Volver al inicio'),
  ]));
}
