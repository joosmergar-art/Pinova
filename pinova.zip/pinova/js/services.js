// ============================================================
// PINOVA — Servicios de acceso a datos (Supabase)
// ============================================================

// Columnas explícitas de pn_posts para lecturas normales del feed/detalle.
// Se excluyen embedding y phash a propósito: son datos internos para
// búsqueda visual y no hace falta traerlos en cada consulta del feed.
const POST_COLUMNS = 'id,author_id,title,description,image_url,image_width,image_height,external_link,category_id,tags,save_count,like_count,comment_count,created_at,updated_at';

const PostsService = {
  async fetchFeed({ page = 0, categorySlug = null } = {}) {
    const from = page * PINOVA_CONFIG.postsPerPage;
    const to = from + PINOVA_CONFIG.postsPerPage - 1;
    let query = supabaseClient
      .from('pn_posts')
      .select(`${POST_COLUMNS}, author:pn_profiles!pn_posts_author_id_fkey(id,username,display_name,avatar_url), category:pn_categories(slug,label)`)
      .order('created_at', { ascending: false })
      .range(from, to);
    if (categorySlug) {
      const { data: cat } = await supabaseClient.from('pn_categories').select('id').eq('slug', categorySlug).single();
      if (cat) query = query.eq('category_id', cat.id);
    }
    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  async fetchById(postId) {
    const { data, error } = await supabaseClient
      .from('pn_posts')
      .select(`${POST_COLUMNS}, author:pn_profiles!pn_posts_author_id_fkey(id,username,display_name,avatar_url,bio), category:pn_categories(slug,label)`)
      .eq('id', postId)
      .single();
    if (error) throw error;
    return data;
  },

  async fetchByAuthor(authorId) {
    const { data, error } = await supabaseClient
      .from('pn_posts')
      .select(`${POST_COLUMNS}, author:pn_profiles!pn_posts_author_id_fkey(id,username,display_name,avatar_url)`)
      .eq('author_id', authorId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  async fetchRelated(post) {
    const { data, error } = await supabaseClient
      .from('pn_posts')
      .select(`${POST_COLUMNS}, author:pn_profiles!pn_posts_author_id_fkey(id,username,display_name,avatar_url)`)
      .eq('category_id', post.category_id)
      .neq('id', post.id)
      .limit(12);
    if (error) throw error;
    return data;
  },

  async search(term) {
    const { data, error } = await supabaseClient
      .from('pn_posts')
      .select(`${POST_COLUMNS}, author:pn_profiles!pn_posts_author_id_fkey(id,username,display_name,avatar_url)`)
      .textSearch('title', term, { type: 'websearch', config: 'spanish' })
      .limit(60);
    if (error) {
      // fallback a ilike si la búsqueda de texto completo falla (p.ej. término corto)
      const fallback = await supabaseClient
        .from('pn_posts')
        .select(`${POST_COLUMNS}, author:pn_profiles!pn_posts_author_id_fkey(id,username,display_name,avatar_url)`)
        .or(`title.ilike.%${term}%,description.ilike.%${term}%`)
        .limit(60);
      return fallback.data || [];
    }
    return data;
  },

  async create(payload) {
    const { data, error } = await supabaseClient
      .from('pn_posts')
      .insert(payload)
      .select(POST_COLUMNS)
      .single();
    if (error) throw error;
    return data;
  },

  async update(postId, payload) {
    const { data, error } = await supabaseClient
      .from('pn_posts')
      .update(payload)
      .eq('id', postId)
      .select(POST_COLUMNS)
      .single();
    if (error) throw error;
    return data;
  },

  async remove(postId) {
    const { error } = await supabaseClient.from('pn_posts').delete().eq('id', postId);
    if (error) throw error;
  },

  async uploadImage(file, userId) {
    const ext = file.name.split('.').pop();
    const path = `${userId}/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabaseClient.storage
      .from(PINOVA_CONFIG.storageBucket)
      .upload(path, file, { cacheControl: '3600', upsert: false });
    if (error) throw error;
    const { data } = supabaseClient.storage.from(PINOVA_CONFIG.storageBucket).getPublicUrl(path);
    return data.publicUrl;
  },
};

const InteractionsService = {
  async isSaved(userId, postId) {
    if (!userId) return false;
    const { data } = await supabaseClient.from('pn_saves').select('*').eq('user_id', userId).eq('post_id', postId).maybeSingle();
    return !!data;
  },
  async isLiked(userId, postId) {
    if (!userId) return false;
    const { data } = await supabaseClient.from('pn_likes').select('*').eq('user_id', userId).eq('post_id', postId).maybeSingle();
    return !!data;
  },
  async toggleSave(userId, postId, currentlySaved) {
    if (currentlySaved) {
      await supabaseClient.from('pn_saves').delete().eq('user_id', userId).eq('post_id', postId);
      return false;
    } else {
      await supabaseClient.from('pn_saves').insert({ user_id: userId, post_id: postId });
      return true;
    }
  },
  async toggleLike(userId, postId, currentlyLiked) {
    if (currentlyLiked) {
      await supabaseClient.from('pn_likes').delete().eq('user_id', userId).eq('post_id', postId);
      return false;
    } else {
      await supabaseClient.from('pn_likes').insert({ user_id: userId, post_id: postId });
      return true;
    }
  },
  async fetchSavedByUser(userId) {
    const { data, error } = await supabaseClient
      .from('pn_saves')
      .select(`created_at, post:pn_posts(${POST_COLUMNS}, author:pn_profiles!pn_posts_author_id_fkey(id,username,display_name,avatar_url))`)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data || []).map(r => r.post).filter(Boolean);
  },
  async fetchComments(postId) {
    const { data, error } = await supabaseClient
      .from('pn_comments')
      .select('*, author:pn_profiles!pn_comments_author_id_fkey(id,username,display_name,avatar_url)')
      .eq('post_id', postId)
      .order('created_at', { ascending: true });
    if (error) throw error;
    return data;
  },
  async addComment(postId, authorId, body) {
    const { data, error } = await supabaseClient
      .from('pn_comments')
      .insert({ post_id: postId, author_id: authorId, body })
      .select('*, author:pn_profiles!pn_comments_author_id_fkey(id,username,display_name,avatar_url)')
      .single();
    if (error) throw error;
    return data;
  },
  async removeComment(commentId) {
    const { error } = await supabaseClient.from('pn_comments').delete().eq('id', commentId);
    if (error) throw error;
  },
};

const FollowService = {
  async isFollowing(followerId, followingId) {
    if (!followerId) return false;
    const { data } = await supabaseClient.from('pn_follows').select('*').eq('follower_id', followerId).eq('following_id', followingId).maybeSingle();
    return !!data;
  },
  async toggle(followerId, followingId, currentlyFollowing) {
    if (currentlyFollowing) {
      await supabaseClient.from('pn_follows').delete().eq('follower_id', followerId).eq('following_id', followingId);
      return false;
    } else {
      await supabaseClient.from('pn_follows').insert({ follower_id: followerId, following_id: followingId });
      return true;
    }
  },
  async counts(userId) {
    const [{ count: followers }, { count: following }] = await Promise.all([
      supabaseClient.from('pn_follows').select('*', { count: 'exact', head: true }).eq('following_id', userId),
      supabaseClient.from('pn_follows').select('*', { count: 'exact', head: true }).eq('follower_id', userId),
    ]);
    return { followers: followers || 0, following: following || 0 };
  },
  async fetchFollowers(userId) {
    const { data } = await supabaseClient.from('pn_follows').select('follower:pn_profiles!pn_follows_follower_id_fkey(*)').eq('following_id', userId);
    return (data || []).map(r => r.follower);
  },
  async fetchFollowing(userId) {
    const { data } = await supabaseClient.from('pn_follows').select('following:pn_profiles!pn_follows_following_id_fkey(*)').eq('follower_id', userId);
    return (data || []).map(r => r.following);
  },
};

const BoardsService = {
  async fetchByOwner(ownerId, includePrivate = false) {
    let query = supabaseClient.from('pn_boards').select('*, post_count:pn_board_posts(count)').eq('owner_id', ownerId);
    if (!includePrivate) query = query.eq('is_public', true);
    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) throw error;
    return (data || []).map(b => ({ ...b, post_count: b.post_count?.[0]?.count || 0 }));
  },
  async fetchById(boardId) {
    const { data, error } = await supabaseClient
      .from('pn_boards')
      .select('*, owner:pn_profiles(*)')
      .eq('id', boardId)
      .single();
    if (error) throw error;
    return data;
  },
  async fetchPosts(boardId) {
    const { data, error } = await supabaseClient
      .from('pn_board_posts')
      .select(`post:pn_posts(${POST_COLUMNS}, author:pn_profiles!pn_posts_author_id_fkey(id,username,display_name,avatar_url))`)
      .eq('board_id', boardId)
      .order('added_at', { ascending: false });
    if (error) throw error;
    return (data || []).map(r => r.post).filter(Boolean);
  },
  async create({ ownerId, name, description, isPublic }) {
    const { data, error } = await supabaseClient
      .from('pn_boards')
      .insert({ owner_id: ownerId, name, description, is_public: isPublic })
      .select()
      .single();
    if (error) throw error;
    return data;
  },
  async addPost(boardId, postId, coverUrl) {
    const { error } = await supabaseClient.from('pn_board_posts').insert({ board_id: boardId, post_id: postId });
    if (error && error.code !== '23505') throw error; // ignora duplicado
    // actualizar portada si el tablero no tiene una
    const { data: board } = await supabaseClient.from('pn_boards').select('cover_url').eq('id', boardId).single();
    if (board && !board.cover_url) {
      await supabaseClient.from('pn_boards').update({ cover_url: coverUrl }).eq('id', boardId);
    }
  },
  async removePost(boardId, postId) {
    const { error } = await supabaseClient.from('pn_board_posts').delete().eq('board_id', boardId).eq('post_id', postId);
    if (error) throw error;
  },
  async remove(boardId) {
    const { error } = await supabaseClient.from('pn_boards').delete().eq('id', boardId);
    if (error) throw error;
  },
};

const NotificationsService = {
  async fetch(userId) {
    const { data, error } = await supabaseClient
      .from('pn_notifications')
      .select('*, actor:pn_profiles!pn_notifications_actor_id_fkey(username,display_name,avatar_url), post:pn_posts(id,title,image_url)')
      .eq('recipient_id', userId)
      .order('created_at', { ascending: false })
      .limit(40);
    if (error) throw error;
    return data;
  },
  async unreadCount(userId) {
    const { count } = await supabaseClient.from('pn_notifications').select('*', { count: 'exact', head: true }).eq('recipient_id', userId).eq('read', false);
    return count || 0;
  },
  async markAllRead(userId) {
    await supabaseClient.from('pn_notifications').update({ read: true }).eq('recipient_id', userId).eq('read', false);
  },
};

const ProfilesService = {
  async fetchByUsername(username) {
    const { data, error } = await supabaseClient.from('pn_profiles').select('*').eq('username', username).single();
    if (error) throw error;
    return data;
  },
  async update(userId, payload) {
    const { data, error } = await supabaseClient.from('pn_profiles').update(payload).eq('id', userId).select().single();
    if (error) throw error;
    return data;
  },
  async uploadAvatar(file, userId) {
    const ext = file.name.split('.').pop();
    const path = `avatars/${userId}.${ext}`;
    const { error } = await supabaseClient.storage
      .from(PINOVA_CONFIG.storageBucket)
      .upload(path, file, { cacheControl: '3600', upsert: true });
    if (error) throw error;
    const { data } = supabaseClient.storage.from(PINOVA_CONFIG.storageBucket).getPublicUrl(path);
    return data.publicUrl + '?t=' + Date.now();
  },
};

const VisualSearchService = {
  async searchByEmbedding(embedding, threshold = 0.35, limit = 24) {
    const { data, error } = await supabaseClient.rpc('pn_match_posts_by_embedding', {
      query_embedding: embedding,
      match_threshold: threshold,
      match_count: limit,
    });
    if (error) throw error;
    return data || [];
  },

  /**
   * Busca coincidencias exactas/casi-exactas comparando pHash en el cliente.
   * Trae un lote de posts con phash y calcula distancia de Hamming localmente,
   * ya que Postgres no tiene el hash como tipo indexable para esto sin extensiones extra.
   */
  async searchByPHash(targetHash, maxDistance = 8) {
    const { data, error } = await supabaseClient
      .from('pn_posts')
      .select('id, title, image_url, author_id, save_count, phash')
      .not('phash', 'is', null)
      .limit(2000);
    if (error) throw error;
    return (data || [])
      .map(p => ({ ...p, distance: VisualSearch.hammingDistance(targetHash, p.phash) }))
      .filter(p => p.distance <= maxDistance)
      .sort((a, b) => a.distance - b.distance);
  },

  async hydratePosts(rows) {
    if (!rows || rows.length === 0) return [];
    const ids = rows.map(r => r.id);
    const { data } = await supabaseClient
      .from('pn_posts')
      .select(`${POST_COLUMNS}, author:pn_profiles!pn_posts_author_id_fkey(id,username,display_name,avatar_url)`)
      .in('id', ids);
    const byId = new Map((data || []).map(p => [p.id, p]));
    return ids.map(id => byId.get(id)).filter(Boolean);
  },
};

const CategoriesService = {
  _cache: null,
  async fetchAll() {
    if (this._cache) return this._cache;
    const { data, error } = await supabaseClient.from('pn_categories').select('*').order('id');
    if (error) throw error;
    this._cache = data;
    return data;
  },
};
