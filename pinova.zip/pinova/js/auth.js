// ============================================================
// PINOVA — Autenticación y estado de sesión
// ============================================================

const PinovaAuth = {
  user: null,       // objeto de auth.users
  profile: null,     // fila de pn_profiles
  listeners: [],

  onChange(fn) {
    this.listeners.push(fn);
  },

  notify() {
    this.listeners.forEach(fn => fn(this.user, this.profile));
  },

  async init() {
    const { data: { session } } = await supabaseClient.auth.getSession();
    if (session) {
      this.user = session.user;
      await this.loadProfile();
    }
    supabaseClient.auth.onAuthStateChange(async (event, session) => {
      this.user = session?.user || null;
      if (this.user) {
        await this.loadProfile();
      } else {
        this.profile = null;
      }
      this.notify();
    });
    this.notify();
  },

  async loadProfile() {
    if (!this.user) return;
    const { data } = await supabaseClient
      .from('pn_profiles')
      .select('*')
      .eq('id', this.user.id)
      .single();
    this.profile = data;
  },

  async signUp({ email, password, username, displayName }) {
    const { data, error } = await supabaseClient.auth.signUp({
      email,
      password,
      options: { data: { username, display_name: displayName } },
    });
    if (error) throw error;
    return data;
  },

  async signIn({ email, password }) {
    const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
    if (error) throw error;
    this.user = data.user;
    await this.loadProfile();
    this.notify();
    return data;
  },

  async signOut() {
    await supabaseClient.auth.signOut();
    this.user = null;
    this.profile = null;
    this.notify();
  },

  async resetPassword(email) {
    const { error } = await supabaseClient.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.href.split('#')[0] + '#/reset-password',
    });
    if (error) throw error;
  },

  async updatePassword(newPassword) {
    const { error } = await supabaseClient.auth.updateUser({ password: newPassword });
    if (error) throw error;
  },

  isLoggedIn() {
    return !!this.user;
  },

  requireAuth() {
    if (!this.isLoggedIn()) {
      toast('Inicia sesión para continuar', 'default');
      location.hash = '#/login';
      return false;
    }
    return true;
  },
};
