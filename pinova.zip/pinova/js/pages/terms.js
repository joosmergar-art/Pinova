// ============================================================
// PINOVA — Página: Términos y Condiciones
// ============================================================

function pageTerms(root) {
  const wrap = el('div', { class: 'pn-legal-page pn-page-pad' });
  wrap.innerHTML = `
    <h1 class="pn-page-title">Términos y Condiciones</h1>
    <p class="pn-legal-updated">Última actualización: ${new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}</p>

    <p>Bienvenido a Pinova. Al crear una cuenta o usar esta plataforma, aceptas los siguientes términos. Léelos con atención.</p>

    <h2>1. Descripción del servicio</h2>
    <p>Pinova es una plataforma visual que permite descubrir, publicar, guardar y organizar imágenes en tableros y categorías, con funciones sociales como seguir a otros usuarios, comentar y buscar contenido por texto o por imagen.</p>

    <h2>2. Cuentas de usuario</h2>
    <ul>
      <li>Debes proporcionar información veraz al registrarte.</li>
      <li>Eres responsable de mantener la confidencialidad de tu contraseña y de toda actividad realizada desde tu cuenta.</li>
      <li>Debes tener al menos 13 años para crear una cuenta en Pinova.</li>
      <li>Nos reservamos el derecho de suspender o eliminar cuentas que incumplan estos términos.</li>
    </ul>

    <h2>3. Contenido publicado por usuarios</h2>
    <ul>
      <li>Eres el único responsable del contenido que publiques (imágenes, títulos, descripciones, comentarios).</li>
      <li>Al publicar contenido, garantizas que tienes los derechos necesarios para hacerlo, o que se trata de contenido de uso libre (por ejemplo, imágenes obtenidas a través de la función de búsqueda de imágenes libres de copyright integrada en la plataforma).</li>
      <li>No está permitido publicar contenido que infrinja derechos de autor, sea ilegal, difamatorio, de odio, sexualmente explícito, o que vulnere los derechos de terceros.</li>
      <li>Nos reservamos el derecho de eliminar cualquier contenido que incumpla estos términos, sin previo aviso.</li>
      <li>Al publicar contenido en Pinova, concedes a la plataforma una licencia no exclusiva para almacenarlo, mostrarlo y distribuirlo dentro del servicio, con el único fin de operar la plataforma.</li>
    </ul>

    <h2>4. Uso aceptable</h2>
    <p>Al usar Pinova, te comprometes a no:</p>
    <ul>
      <li>Suplantar la identidad de otra persona o entidad.</li>
      <li>Usar la plataforma para acosar, amenazar o dañar a otros usuarios.</li>
      <li>Intentar acceder sin autorización a cuentas, datos o sistemas de la plataforma.</li>
      <li>Usar bots, scraping automatizado u otras técnicas para extraer contenido masivamente sin autorización.</li>
      <li>Publicar spam o contenido engañoso de forma repetida.</li>
    </ul>

    <h2>5. Propiedad intelectual de la plataforma</h2>
    <p>El nombre "Pinova", su diseño, logotipo e interfaz son propiedad de sus creadores. Estos términos no te otorgan ningún derecho sobre ellos más allá del uso normal de la aplicación como usuario.</p>

    <h2>6. Contenido de terceros e imágenes libres de copyright</h2>
    <p>Pinova ofrece una función opcional para buscar e incorporar imágenes a través de bancos de imágenes de terceros (como Pexels). El uso de esas imágenes está sujeto además a los términos de licencia del proveedor correspondiente.</p>

    <h2>7. Disponibilidad del servicio</h2>
    <p>Pinova se ofrece "tal cual" y puede sufrir interrupciones, cambios o discontinuación sin previo aviso, al tratarse de una plataforma en desarrollo activo. No garantizamos disponibilidad ininterrumpida del servicio.</p>

    <h2>8. Limitación de responsabilidad</h2>
    <p>En la medida permitida por la ley aplicable, Pinova no será responsable de daños indirectos derivados del uso de la plataforma, incluyendo pérdida de datos o contenido publicado por usuarios.</p>

    <h2>9. Terminación de cuenta</h2>
    <p>Puedes dejar de usar Pinova en cualquier momento. Podemos suspender o eliminar cuentas que incumplan gravemente estos términos.</p>

    <h2>10. Cambios a estos términos</h2>
    <p>Podemos actualizar estos términos conforme la plataforma evolucione, especialmente a medida que se prepare para un uso más amplio o comercial. El uso continuado de Pinova tras un cambio implica la aceptación de los nuevos términos.</p>

    <h2>11. Contacto</h2>
    <p>Actualmente no contamos con un canal de contacto público. Esta sección se actualizará en cuanto esté disponible un correo o formulario de contacto oficial.</p>
  `;
  root.appendChild(wrap);
}
