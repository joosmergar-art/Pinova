// ============================================================
// PINOVA — Página: Detalle de tablero
// ============================================================

async function pageBoard(root, params) {
  const wrap = el('div', { class: 'pn-page-pad' });
  wrap.appendChild(el('div', { class: 'pn-spinner-wrap pn-spinner-full' }, el('div', { class: 'pn-spinner' })));
  root.appendChild(wrap);

  let board;
  try {
    board = await BoardsService.fetchById(params.id);
  } catch {
    wrap.innerHTML = '';
    wrap.appendChild(el('div', { class: 'pn-empty-state' }, [
      icon('layout-grid', 44),
      el('h2', {}, 'Tablero no encontrado'),
      el('button', { class: 'pn-btn pn-btn-primary', onClick: () => PinovaRouter.navigate('/') }, 'Volver al inicio'),
    ]));
    return;
  }

  const isOwner = PinovaAuth.user?.id === board.owner_id;
  if (!board.is_public && !isOwner) {
    wrap.innerHTML = '';
    wrap.appendChild(el('div', { class: 'pn-empty-state' }, [
      icon('lock', 44),
      el('h2', {}, 'Este tablero es privado'),
      el('button', { class: 'pn-btn pn-btn-primary', onClick: () => PinovaRouter.navigate('/') }, 'Volver al inicio'),
    ]));
    return;
  }

  wrap.innerHTML = '';

  const header = el('div', { class: 'pn-board-detail-header' }, [
    el('div', { class: 'pn-board-detail-title-row' }, [
      el('h1', {}, board.name),
      !board.is_public ? icon('lock', 18) : null,
    ]),
    board.description ? el('p', { class: 'pn-board-detail-desc' }, board.description) : null,
    el('a', { href: `#/profile/${board.owner?.username}`, class: 'pn-board-detail-owner' }, [
      renderAvatar(board.owner, 28),
      el('span', {}, board.owner?.display_name),
    ]),
  ]);

  if (isOwner) {
    const delBtn = el('button', { class: 'pn-btn pn-btn-ghost', onClick: async () => {
      const ok = await confirmDialog({ title: 'Eliminar tablero', message: 'Se eliminará el tablero. Las publicaciones no se borrarán.' });
      if (!ok) return;
      try {
        await BoardsService.remove(board.id);
        toast('Tablero eliminado', 'success');
        PinovaRouter.navigate(`/profile/${board.owner.username}`);
      } catch {
        toast('No se pudo eliminar el tablero', 'error');
      }
    } }, [icon('trash-2', 15), ' Eliminar tablero']);
    header.appendChild(delBtn);
  }

  wrap.appendChild(header);
  root.appendChild(wrap);

  createMasonryGrid({
    container: wrap,
    fetchPage: async (page) => (page === 0 ? await BoardsService.fetchPosts(board.id) : []),
    emptyMessage: 'Este tablero todavía está vacío.',
  });
}
