// ============================================================
// PINOVA — Página: Política de Privacidad
// ============================================================

function pagePrivacy(root) {
  const wrap = el('div', { class: 'pn-legal-page pn-page-pad' });
  wrap.innerHTML = `
    <h1 class="pn-page-title">Política de Privacidad</h1>
    <p class="pn-legal-updated">Última actualización: ${new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}</p>

    <p>En Pinova nos tomamos en serio la privacidad de quienes usan la plataforma. Este documento explica qué datos recopilamos, cómo los usamos y qué opciones tienes sobre ellos.</p>

    <h2>1. Qué datos recopilamos</h2>
    <p>Cuando creas una cuenta y usas Pinova, podemos recopilar:</p>
    <ul>
      <li><strong>Datos de cuenta:</strong> correo electrónico, nombre de usuario, nombre para mostrar y contraseña (almacenada de forma cifrada, nunca en texto plano).</li>
      <li><strong>Contenido que publicas:</strong> imágenes, títulos, descripciones, etiquetas, comentarios y tableros que crees.</li>
      <li><strong>Datos de perfil opcionales:</strong> biografía y foto de perfil, si decides añadirlos.</li>
      <li><strong>Datos de uso e interacción:</strong> publicaciones guardadas, seguidores, "me gusta" y notificaciones, necesarios para el funcionamiento básico de la plataforma.</li>
      <li><strong>Análisis visual de imágenes:</strong> al publicar una imagen, se genera de forma local en tu dispositivo una huella técnica (vector de características y hash) que permite ofrecer la función de búsqueda por foto. Esta huella no permite identificarte a ti como persona, solo comparar imágenes entre sí.</li>
    </ul>

    <h2>2. Cómo usamos tus datos</h2>
    <p>Usamos la información recopilada para:</p>
    <ul>
      <li>Crear y mantener tu cuenta y perfil público.</li>
      <li>Mostrar, organizar y permitir la búsqueda de contenido dentro de la plataforma.</li>
      <li>Habilitar funciones sociales: seguir usuarios, guardar publicaciones, comentar y recibir notificaciones.</li>
      <li>Mejorar la experiencia de la aplicación y corregir errores.</li>
    </ul>
    <p>No vendemos tus datos personales a terceros.</p>

    <h2>3. Servicios de terceros que utilizamos</h2>
    <p>Pinova se apoya en los siguientes proveedores externos para funcionar:</p>
    <ul>
      <li><strong>Supabase:</strong> aloja la base de datos, el sistema de autenticación y el almacenamiento de imágenes de la plataforma.</li>
      <li><strong>Pexels:</strong> si eliges usar la función de búsqueda de imágenes libres de copyright al crear una publicación, esa búsqueda se realiza a través de la API pública de Pexels.</li>
    </ul>
    <p>Estos proveedores tienen sus propias políticas de privacidad, que te recomendamos revisar si tienes dudas específicas sobre cómo manejan los datos que procesan en nuestro nombre.</p>

    <h2>4. Contenido público</h2>
    <p>Ten en cuenta que las publicaciones, perfiles públicos, tableros públicos, comentarios y la lista de seguidores/seguidos son visibles para cualquier persona que use la plataforma, salvo que marques un tablero como privado.</p>

    <h2>5. Tus derechos y opciones</h2>
    <ul>
      <li>Puedes editar tu nombre, biografía y foto de perfil en cualquier momento desde tu perfil.</li>
      <li>Puedes eliminar tus publicaciones, comentarios y tableros individualmente.</li>
      <li>Puedes eliminar una publicación completa, lo que también elimina su imagen asociada.</li>
      <li>Si deseas eliminar tu cuenta por completo, puedes solicitarlo; mientras no exista un correo de contacto público, esta opción estará disponible próximamente desde la propia aplicación.</li>
    </ul>

    <h2>6. Menores de edad</h2>
    <p>Pinova no está dirigida a menores de 13 años. Si tienes conocimiento de que un menor de esa edad ha creado una cuenta, contáctanos para proceder a su eliminación.</p>

    <h2>7. Seguridad</h2>
    <p>Aplicamos medidas técnicas razonables para proteger tu información, incluyendo cifrado de contraseñas y reglas de acceso a nivel de base de datos (Row Level Security) que restringen quién puede leer o modificar cada dato. Ninguna plataforma puede garantizar seguridad absoluta, pero trabajamos para minimizar riesgos.</p>

    <h2>8. Cambios a esta política</h2>
    <p>Podemos actualizar esta política conforme la plataforma evolucione. Si los cambios son significativos, intentaremos avisarlo de forma visible dentro de la aplicación.</p>

    <h2>9. Contacto</h2>
    <p>Actualmente no contamos con un canal de contacto público. Esta sección se actualizará en cuanto esté disponible un correo o formulario de contacto oficial.</p>
  `;
  root.appendChild(wrap);
}
