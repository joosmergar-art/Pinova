// ============================================================
// PINOVA — Páginas: Login, Registro, Recuperar contraseña
// ============================================================

function renderAuthShell(title, subtitle, formEl, footerEl) {
  const wrap = el('div', { class: 'pn-auth-page' });
  const card = el('div', { class: 'pn-auth-card' }, [
    el('a', { href: '#/', class: 'pn-logo pn-auth-logo' }, [
      el('span', { class: 'pn-logo-mark' }, '◆'),
      el('span', { class: 'pn-logo-text' }, 'Pinova'),
    ]),
    el('h1', { class: 'pn-auth-title' }, title),
    el('p', { class: 'pn-auth-subtitle' }, subtitle),
    formEl,
    footerEl,
    el('p', { class: 'pn-auth-legal-links' }, [
      el('a', { href: '#/terms' }, 'Términos'),
      ' · ',
      el('a', { href: '#/privacy' }, 'Privacidad'),
    ]),
  ]);
  wrap.appendChild(card);
  return wrap;
}

function pageLogin(root) {
  const emailInput = el('input', { type: 'email', class: 'pn-input', placeholder: 'Correo electrónico', required: 'true', autocomplete: 'email' });
  const passInput = el('input', { type: 'password', class: 'pn-input', placeholder: 'Contraseña', required: 'true', autocomplete: 'current-password' });
  const submitBtn = el('button', { type: 'submit', class: 'pn-btn pn-btn-primary pn-btn-block' }, 'Iniciar sesión');

  const form = el('form', { class: 'pn-auth-form' }, [
    el('label', { class: 'pn-field' }, [el('span', {}, 'Correo'), emailInput]),
    el('label', { class: 'pn-field' }, [el('span', {}, 'Contraseña'), passInput]),
    el('a', { href: '#/forgot-password', class: 'pn-auth-link-small' }, '¿Olvidaste tu contraseña?'),
    submitBtn,
  ]);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    submitBtn.disabled = true;
    submitBtn.textContent = 'Entrando...';
    try {
      await PinovaAuth.signIn({ email: emailInput.value.trim(), password: passInput.value });
      toast('Bienvenido de nuevo', 'success');
      PinovaRouter.navigate('/');
    } catch (err) {
      toast(err.message === 'Invalid login credentials' ? 'Correo o contraseña incorrectos' : 'No se pudo iniciar sesión', 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Iniciar sesión';
    }
  });

  const footer = el('p', { class: 'pn-auth-footer' }, ['¿No tienes cuenta? ', el('a', { href: '#/signup' }, 'Regístrate')]);
  root.appendChild(renderAuthShell('Bienvenido de nuevo', 'Inicia sesión para seguir descubriendo', form, footer));
}

function pageSignup(root) {
  const nameInput = el('input', { type: 'text', class: 'pn-input', placeholder: 'Nombre completo', required: 'true', maxlength: '60' });
  const userInput = el('input', { type: 'text', class: 'pn-input', placeholder: 'nombre_usuario', required: 'true', pattern: '[a-z0-9_]{3,20}', maxlength: '20' });
  const emailInput = el('input', { type: 'email', class: 'pn-input', placeholder: 'Correo electrónico', required: 'true', autocomplete: 'email' });
  const passInput = el('input', { type: 'password', class: 'pn-input', placeholder: 'Contraseña (mínimo 6 caracteres)', required: 'true', minlength: '6', autocomplete: 'new-password' });
  const submitBtn = el('button', { type: 'submit', class: 'pn-btn pn-btn-primary pn-btn-block' }, 'Crear cuenta');

  const form = el('form', { class: 'pn-auth-form' }, [
    el('label', { class: 'pn-field' }, [el('span', {}, 'Nombre'), nameInput]),
    el('label', { class: 'pn-field' }, [el('span', {}, 'Usuario'), userInput]),
    el('p', { class: 'pn-field-hint' }, 'Minúsculas, números y guion bajo. 3-20 caracteres.'),
    el('label', { class: 'pn-field' }, [el('span', {}, 'Correo'), emailInput]),
    el('label', { class: 'pn-field' }, [el('span', {}, 'Contraseña'), passInput]),
    submitBtn,
  ]);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    submitBtn.disabled = true;
    submitBtn.textContent = 'Creando cuenta...';
    try {
      await PinovaAuth.signUp({
        email: emailInput.value.trim(),
        password: passInput.value,
        username: userInput.value.trim().toLowerCase(),
        displayName: nameInput.value.trim(),
      });
      toast('Cuenta creada. Revisa tu correo si se requiere confirmación.', 'success');
      PinovaRouter.navigate('/');
    } catch (err) {
      let msg = 'No se pudo crear la cuenta';
      if (err.message?.includes('already registered')) msg = 'Ese correo ya está registrado';
      if (err.message?.includes('duplicate') || err.code === '23505') msg = 'Ese nombre de usuario ya está en uso';
      toast(msg, 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Crear cuenta';
    }
  });

  const footer = el('p', { class: 'pn-auth-footer' }, ['¿Ya tienes cuenta? ', el('a', { href: '#/login' }, 'Inicia sesión')]);
  root.appendChild(renderAuthShell('Únete a Pinova', 'Descubre, guarda y comparte lo que te inspira', form, footer));
}

function pageForgotPassword(root) {
  const emailInput = el('input', { type: 'email', class: 'pn-input', placeholder: 'Correo electrónico', required: 'true' });
  const submitBtn = el('button', { type: 'submit', class: 'pn-btn pn-btn-primary pn-btn-block' }, 'Enviar enlace de recuperación');

  const form = el('form', { class: 'pn-auth-form' }, [
    el('label', { class: 'pn-field' }, [el('span', {}, 'Correo'), emailInput]),
    submitBtn,
  ]);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    submitBtn.disabled = true;
    submitBtn.textContent = 'Enviando...';
    try {
      await PinovaAuth.resetPassword(emailInput.value.trim());
      toast('Revisa tu correo para restablecer tu contraseña', 'success');
    } catch {
      toast('No se pudo enviar el correo de recuperación', 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Enviar enlace de recuperación';
    }
  });

  const footer = el('p', { class: 'pn-auth-footer' }, [el('a', { href: '#/login' }, '← Volver a iniciar sesión')]);
  root.appendChild(renderAuthShell('Recuperar contraseña', 'Te enviaremos un enlace a tu correo', form, footer));
}

function pageResetPassword(root) {
  const passInput = el('input', { type: 'password', class: 'pn-input', placeholder: 'Nueva contraseña', required: 'true', minlength: '6' });
  const submitBtn = el('button', { type: 'submit', class: 'pn-btn pn-btn-primary pn-btn-block' }, 'Actualizar contraseña');

  const form = el('form', { class: 'pn-auth-form' }, [
    el('label', { class: 'pn-field' }, [el('span', {}, 'Nueva contraseña'), passInput]),
    submitBtn,
  ]);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    submitBtn.disabled = true;
    try {
      await PinovaAuth.updatePassword(passInput.value);
      toast('Contraseña actualizada', 'success');
      PinovaRouter.navigate('/');
    } catch {
      toast('No se pudo actualizar la contraseña', 'error');
      submitBtn.disabled = false;
    }
  });

  root.appendChild(renderAuthShell('Nueva contraseña', 'Elige una contraseña segura', form, el('div')));
}
