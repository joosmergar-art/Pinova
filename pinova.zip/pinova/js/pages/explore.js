// ============================================================
// PINOVA — Página: Explorar
// ============================================================

async function pageExplore(root, params, query) {
  const categorySlug = query.get('cat');

  if (categorySlug) {
    const cats = await CategoriesService.fetchAll();
    const cat = cats.find(c => c.slug === categorySlug);
    const wrap = el('div', { class: 'pn-page-pad' });
    wrap.appendChild(el('div', { class: 'pn-explore-header' }, [
      el('button', { class: 'pn-back-btn', onClick: () => PinovaRouter.navigate('/explore') }, icon('arrow-left', 18)),
      el('h1', {}, cat ? cat.label : 'Categoría'),
    ]));
    root.appendChild(wrap);
    createMasonryGrid({
      container: wrap,
      fetchPage: (page) => PostsService.fetchFeed({ page, categorySlug }),
      emptyMessage: 'Aún no hay publicaciones en esta categoría.',
    });
    return;
  }

  const wrap = el('div', { class: 'pn-page-pad' });
  wrap.appendChild(el('h1', { class: 'pn-page-title' }, 'Explorar'));

  const searchInput = el('input', { type: 'text', class: 'pn-explore-search-input', placeholder: 'Buscar imágenes, temas o personas' });
  const cameraBtn = el('button', {
    type: 'button', class: 'pn-explore-camera-btn',
    onClick: (e) => { e.preventDefault(); showVisualSearchModal(); },
  }, icon('camera', 19));
  const searchForm = el('form', { class: 'pn-explore-search-form' }, [icon('search', 19), searchInput, cameraBtn]);
  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const term = searchInput.value.trim();
    if (term) PinovaRouter.navigate(`/search?q=${encodeURIComponent(term)}`);
  });
  wrap.appendChild(searchForm);

  const catsGrid = el('div', { class: 'pn-explore-cats' });
  wrap.appendChild(el('section', { class: 'pn-explore-section' }, [
    el('h2', {}, 'Categorías'),
    catsGrid,
  ]));

  const creatorsRow = el('div', { class: 'pn-creators-row' }, el('div', { class: 'pn-spinner-wrap' }, el('div', { class: 'pn-spinner' })));
  wrap.appendChild(el('section', { class: 'pn-explore-section' }, [
    el('h2', {}, 'Creadores destacados'),
    creatorsRow,
  ]));

  const trendingTitle = el('h2', {}, 'Tendencias');
  const trendingGridWrap = el('div', {});
  wrap.appendChild(el('section', { class: 'pn-explore-section' }, [trendingTitle, trendingGridWrap]));

  root.appendChild(wrap);

  CategoriesService.fetchAll().then(cats => {
    const gradients = [
      'linear-gradient(135deg,#3B5BFD,#7C9BFF)', 'linear-gradient(135deg,#18181B,#52525B)',
      'linear-gradient(135deg,#D97757,#F0B090)', 'linear-gradient(135deg,#0EA5A5,#5EEAD4)',
      'linear-gradient(135deg,#7C3AED,#C4B5FD)', 'linear-gradient(135deg,#DB2777,#F9A8D4)',
    ];
    cats.forEach((c, i) => {
      const tile = el('a', {
        href: `#/explore?cat=${c.slug}`,
        class: 'pn-cat-tile',
        style: `background:${gradients[i % gradients.length]}`,
      }, el('span', {}, c.label));
      catsGrid.appendChild(tile);
    });
  });

  supabaseClient
    .from('pn_profiles')
    .select('*')
    .limit(8)
    .then(({ data }) => {
      creatorsRow.innerHTML = '';
      if (!data || data.length === 0) {
        creatorsRow.appendChild(el('p', { class: 'pn-muted' }, 'Todavía no hay creadores para mostrar.'));
        return;
      }
      data.forEach(profile => {
        creatorsRow.appendChild(el('a', { href: `#/profile/${profile.username}`, class: 'pn-creator-chip' }, [
          renderAvatar(profile, 52),
          el('span', {}, profile.display_name),
        ]));
      });
    });

  createMasonryGrid({
    container: trendingGridWrap,
    fetchPage: async (page) => {
      if (page > 0) return [];
      const { data } = await supabaseClient
        .from('pn_posts')
        .select(`${POST_COLUMNS}, author:pn_profiles!pn_posts_author_id_fkey(id,username,display_name,avatar_url)`)
        .order('save_count', { ascending: false })
        .limit(18);
      return data;
    },
    emptyMessage: 'Aún no hay tendencias.',
  });
}
