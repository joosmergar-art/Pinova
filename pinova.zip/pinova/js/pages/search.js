// ============================================================
// PINOVA — Página: Resultados de búsqueda
// ============================================================

async function pageSearch(root, params, query) {
  const term = query.get('q') || '';
  const wrap = el('div', { class: 'pn-page-pad' });

  const input = el('input', { type: 'text', class: 'pn-input pn-search-page-input', value: term, placeholder: 'Buscar imágenes, temas o personas' });
  const form = el('form', { class: 'pn-search-page-form' }, [icon('search', 18), input]);
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (input.value.trim()) PinovaRouter.navigate(`/search?q=${encodeURIComponent(input.value.trim())}`);
  });
  wrap.appendChild(form);

  wrap.appendChild(el('h1', { class: 'pn-page-title' }, term ? `Resultados para "${term}"` : 'Buscar'));

  const usersRow = el('div', { class: 'pn-search-users-row' });
  const resultsWrap = el('div', {});
  wrap.appendChild(usersRow);
  wrap.appendChild(resultsWrap);
  root.appendChild(wrap);

  if (!term) {
    resultsWrap.appendChild(el('div', { class: 'pn-empty-state' }, [
      icon('search', 40),
      el('p', {}, 'Escribe algo para empezar a buscar.'),
    ]));
    return;
  }

  supabaseClient
    .from('pn_profiles')
    .select('*')
    .or(`username.ilike.%${term}%,display_name.ilike.%${term}%`)
    .limit(6)
    .then(({ data }) => {
      if (data && data.length > 0) {
        data.forEach(p => {
          usersRow.appendChild(el('a', { href: `#/profile/${p.username}`, class: 'pn-search-user-chip' }, [
            renderAvatar(p, 36),
            el('div', {}, [
              el('span', { class: 'pn-search-user-name' }, p.display_name),
              el('span', { class: 'pn-search-user-handle' }, '@' + p.username),
            ]),
          ]));
        });
      }
    });

  let done = false;
  createMasonryGrid({
    container: resultsWrap,
    fetchPage: async (page) => {
      if (done) return [];
      done = true;
      return await PostsService.search(term);
    },
    emptyMessage: `No encontramos resultados para "${term}".`,
    emptyIcon: 'search-x',
  });
}
