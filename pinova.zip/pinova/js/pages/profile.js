// ============================================================
// PINOVA — Página: Perfil público
// ============================================================

async function pageProfile(root, params) {
  const usernameParam = params.username === 'me' ? PinovaAuth.profile?.username : params.username;
  if (!usernameParam) {
    if (!PinovaAuth.requireAuth()) return;
  }

  const wrap = el('div', { class: 'pn-profile-page' });
  wrap.appendChild(el('div', { class: 'pn-spinner-wrap pn-spinner-full' }, el('div', { class: 'pn-spinner' })));
  root.appendChild(wrap);

  let profile;
  try {
    profile = await ProfilesService.fetchByUsername(usernameParam);
  } catch {
    wrap.innerHTML = '';
    wrap.appendChild(el('div', { class: 'pn-empty-state' }, [
      icon('user-x', 44),
      el('h2', {}, 'Perfil no encontrado'),
      el('button', { class: 'pn-btn pn-btn-primary', onClick: () => PinovaRouter.navigate('/') }, 'Volver al inicio'),
    ]));
    return;
  }

  wrap.innerHTML = '';
  const isSelf = PinovaAuth.user?.id === profile.id;

  const counts = await FollowService.counts(profile.id);
  const isFollowing = isSelf ? false : await FollowService.isFollowing(PinovaAuth.user?.id, profile.id);

  const header = el('div', { class: 'pn-profile-header' });
  header.appendChild(renderAvatar(profile, 96));
  header.appendChild(el('h1', { class: 'pn-profile-name' }, profile.display_name));
  header.appendChild(el('p', { class: 'pn-profile-handle' }, '@' + profile.username));
  if (profile.bio) header.appendChild(el('p', { class: 'pn-profile-bio' }, profile.bio));

  const statsRow = el('div', { class: 'pn-profile-stats' }, [
    el('button', { class: 'pn-stat', onClick: () => showPeopleModal('Seguidores', () => FollowService.fetchFollowers(profile.id)) }, [
      el('strong', {}, String(counts.followers)), el('span', {}, ' seguidores'),
    ]),
    el('button', { class: 'pn-stat', onClick: () => showPeopleModal('Siguiendo', () => FollowService.fetchFollowing(profile.id)) }, [
      el('strong', {}, String(counts.following)), el('span', {}, ' seguidos'),
    ]),
  ]);
  header.appendChild(statsRow);

  const actionRow = el('div', { class: 'pn-profile-actions' });
  if (isSelf) {
    actionRow.appendChild(el('button', { class: 'pn-btn pn-btn-ghost', onClick: () => showEditProfileModal(profile) }, 'Editar perfil'));
    actionRow.appendChild(el('button', { class: 'pn-btn pn-btn-ghost', onClick: async () => { await PinovaAuth.signOut(); toast('Sesión cerrada', 'default'); PinovaRouter.navigate('/'); } }, 'Cerrar sesión'));
  } else {
    const followBtn = el('button', { class: isFollowing ? 'pn-btn pn-btn-ghost' : 'pn-btn pn-btn-primary' }, isFollowing ? 'Siguiendo' : 'Seguir');
    followBtn.addEventListener('click', async () => {
      if (!PinovaAuth.requireAuth()) return;
      const nowFollowing = followBtn.textContent.trim() === 'Siguiendo';
      followBtn.disabled = true;
      const result = await FollowService.toggle(PinovaAuth.user.id, profile.id, nowFollowing);
      followBtn.textContent = result ? 'Siguiendo' : 'Seguir';
      followBtn.className = result ? 'pn-btn pn-btn-ghost' : 'pn-btn pn-btn-primary';
      followBtn.disabled = false;
    });
    actionRow.appendChild(followBtn);
  }
  header.appendChild(actionRow);
  if (isSelf) {
    header.appendChild(el('p', { class: 'pn-auth-legal-links pn-profile-legal-links' }, [
      el('a', { href: '#/terms' }, 'Términos'),
      ' · ',
      el('a', { href: '#/privacy' }, 'Privacidad'),
    ]));
  }
  wrap.appendChild(header);

  // Tabs
  const tabs = el('div', { class: 'pn-profile-tabs' });
  const tabContent = el('div', { class: 'pn-profile-tab-content' });

  const tabDefs = [
    { key: 'posts', label: 'Publicaciones' },
    { key: 'boards', label: 'Tableros' },
  ];
  if (isSelf) tabDefs.push({ key: 'saved', label: 'Guardados' });

  let activeKey = 'posts';
  function renderTabButtons() {
    tabs.innerHTML = '';
    tabDefs.forEach(t => {
      const btn = el('button', { class: `pn-tab ${activeKey === t.key ? 'pn-tab-active' : ''}` }, t.label);
      btn.addEventListener('click', () => { activeKey = t.key; renderTabButtons(); renderTabContent(); });
      tabs.appendChild(btn);
    });
  }
  function renderTabContent() {
    tabContent.innerHTML = '';
    if (activeKey === 'posts') {
      createMasonryGrid({
        container: tabContent,
        fetchPage: async (page) => (page === 0 ? await PostsService.fetchByAuthor(profile.id) : []),
        emptyMessage: isSelf ? 'Aún no has publicado nada.' : 'Esta persona no ha publicado nada todavía.',
      });
    } else if (activeKey === 'boards') {
      renderBoardsTab(tabContent, profile, isSelf);
    } else if (activeKey === 'saved') {
      createMasonryGrid({
        container: tabContent,
        fetchPage: async (page) => (page === 0 ? await InteractionsService.fetchSavedByUser(profile.id) : []),
        emptyMessage: 'No has guardado nada todavía.',
      });
    }
  }
  renderTabButtons();
  renderTabContent();

  wrap.append(tabs, tabContent);
}

function renderBoardsTab(container, profile, isSelf) {
  const grid = el('div', { class: 'pn-boards-grid' });
  container.appendChild(grid);

  if (isSelf) {
    const newBoardCard = el('button', { class: 'pn-board-card pn-board-card-new' }, [icon('plus', 28), el('span', {}, 'Nuevo tablero')]);
    newBoardCard.addEventListener('click', () => showCreateBoardModal(() => renderBoardsTab(container, profile, isSelf)));
    grid.appendChild(newBoardCard);
  }

  BoardsService.fetchByOwner(profile.id, isSelf).then(boards => {
    if (boards.length === 0 && !isSelf) {
      grid.appendChild(el('p', { class: 'pn-muted' }, 'No hay tableros públicos.'));
      return;
    }
    boards.forEach(board => {
      grid.appendChild(el('a', { href: `#/board/${board.id}`, class: 'pn-board-card' }, [
        board.cover_url
          ? el('img', { src: board.cover_url, class: 'pn-board-card-cover' })
          : el('div', { class: 'pn-board-card-cover pn-board-card-cover-empty' }, icon('layout-grid', 28)),
        el('div', { class: 'pn-board-card-info' }, [
          el('span', { class: 'pn-board-card-name' }, [board.name, !board.is_public ? icon('lock', 13) : null]),
          el('span', { class: 'pn-board-card-count' }, `${board.post_count} publicaciones`),
        ]),
      ]));
    });
  });
}

function showCreateBoardModal(onCreated) {
  if (!PinovaAuth.requireAuth()) return;
  const overlay = el('div', { class: 'pn-modal-overlay' });
  const nameInput = el('input', { type: 'text', class: 'pn-input', placeholder: 'Nombre del tablero', required: 'true', maxlength: '60' });
  const descInput = el('textarea', { class: 'pn-input', placeholder: 'Descripción (opcional)', rows: '3', maxlength: '200' });
  const publicCheck = el('input', { type: 'checkbox', checked: 'true' });
  const submitBtn = el('button', { type: 'submit', class: 'pn-btn pn-btn-primary pn-btn-block' }, 'Crear tablero');

  const form = el('form', { class: 'pn-auth-form' }, [
    el('label', { class: 'pn-field' }, [el('span', {}, 'Nombre'), nameInput]),
    el('label', { class: 'pn-field' }, [el('span', {}, 'Descripción'), descInput]),
    el('label', { class: 'pn-checkbox-field' }, [publicCheck, el('span', {}, 'Tablero público')]),
    submitBtn,
  ]);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!nameInput.value.trim()) return;
    submitBtn.disabled = true;
    try {
      await BoardsService.create({
        ownerId: PinovaAuth.user.id,
        name: nameInput.value.trim(),
        description: descInput.value.trim(),
        isPublic: publicCheck.checked,
      });
      toast('Tablero creado', 'success');
      overlay.remove();
      onCreated();
    } catch {
      toast('No se pudo crear el tablero', 'error');
      submitBtn.disabled = false;
    }
  });

  const box = el('div', { class: 'pn-modal-box' }, [
    el('div', { class: 'pn-modal-header' }, [el('h3', {}, 'Nuevo tablero'), el('button', { class: 'pn-modal-close', onClick: () => overlay.remove() }, icon('x', 18))]),
    form,
  ]);
  overlay.appendChild(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function showEditProfileModal(profile) {
  const overlay = el('div', { class: 'pn-modal-overlay' });
  const nameInput = el('input', { type: 'text', class: 'pn-input', value: profile.display_name, maxlength: '60' });
  const bioInput = el('textarea', { class: 'pn-input', rows: '3', maxlength: '200' }, profile.bio || '');
  const avatarFile = el('input', { type: 'file', accept: 'image/*', class: 'pn-hidden-input' });
  const avatarPreview = renderAvatar(profile, 72);
  const avatarLabel = el('label', { class: 'pn-avatar-upload-label' }, [avatarPreview, icon('camera', 14), avatarFile]);
  avatarFile.addEventListener('change', () => {
    const f = avatarFile.files[0];
    if (f) {
      const url = URL.createObjectURL(f);
      avatarLabel.querySelector('.pn-avatar')?.setAttribute('src', url);
    }
  });

  const submitBtn = el('button', { type: 'submit', class: 'pn-btn pn-btn-primary pn-btn-block' }, 'Guardar cambios');
  const form = el('form', { class: 'pn-auth-form' }, [
    avatarLabel,
    el('label', { class: 'pn-field' }, [el('span', {}, 'Nombre'), nameInput]),
    el('label', { class: 'pn-field' }, [el('span', {}, 'Biografía'), bioInput]),
    submitBtn,
  ]);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    submitBtn.disabled = true;
    try {
      const payload = { display_name: nameInput.value.trim(), bio: bioInput.value.trim() };
      if (avatarFile.files[0]) {
        payload.avatar_url = await ProfilesService.uploadAvatar(avatarFile.files[0], PinovaAuth.user.id);
      }
      await ProfilesService.update(PinovaAuth.user.id, payload);
      await PinovaAuth.loadProfile();
      PinovaAuth.notify();
      toast('Perfil actualizado', 'success');
      overlay.remove();
      PinovaRouter.resolve();
    } catch {
      toast('No se pudo actualizar el perfil', 'error');
      submitBtn.disabled = false;
    }
  });

  const box = el('div', { class: 'pn-modal-box' }, [
    el('div', { class: 'pn-modal-header' }, [el('h3', {}, 'Editar perfil'), el('button', { class: 'pn-modal-close', onClick: () => overlay.remove() }, icon('x', 18))]),
    form,
  ]);
  overlay.appendChild(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function showPeopleModal(title, fetchFn) {
  const overlay = el('div', { class: 'pn-modal-overlay' });
  const listWrap = el('div', { class: 'pn-board-list' }, el('div', { class: 'pn-spinner-wrap' }, el('div', { class: 'pn-spinner' })));
  const box = el('div', { class: 'pn-modal-box' }, [
    el('div', { class: 'pn-modal-header' }, [el('h3', {}, title), el('button', { class: 'pn-modal-close', onClick: () => overlay.remove() }, icon('x', 18))]),
    listWrap,
  ]);
  overlay.appendChild(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);

  fetchFn().then(people => {
    listWrap.innerHTML = '';
    if (!people || people.length === 0) {
      listWrap.appendChild(el('p', { class: 'pn-muted' }, 'No hay nadie que mostrar aquí.'));
      return;
    }
    people.forEach(p => {
      listWrap.appendChild(el('a', { href: `#/profile/${p.username}`, class: 'pn-board-row', onClick: () => overlay.remove() }, [
        renderAvatar(p, 40),
        el('div', { class: 'pn-board-row-info' }, [
          el('span', { class: 'pn-board-row-name' }, p.display_name),
          el('span', { class: 'pn-board-row-count' }, '@' + p.username),
        ]),
      ]));
    });
  });
}
