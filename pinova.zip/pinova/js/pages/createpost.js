// ============================================================
// PINOVA — Página: Crear / Editar publicación
// (soporta seleccionar varias imágenes para crear varios posts a la vez)
// ============================================================

async function pageCreatePost(root, params) {
  const isEdit = !!params.id;
  let existingPost = null;
  if (isEdit) {
    try {
      existingPost = await PostsService.fetchById(params.id);
      if (existingPost.author_id !== PinovaAuth.user.id) {
        toast('No puedes editar esta publicación', 'error');
        PinovaRouter.navigate('/');
        return;
      }
    } catch {
      toast('Publicación no encontrada', 'error');
      PinovaRouter.navigate('/');
      return;
    }
  }

  const wrap = el('div', { class: 'pn-create-page pn-page-pad' });
  wrap.appendChild(el('h1', { class: 'pn-page-title' }, isEdit ? 'Editar publicación' : 'Crear publicación'));

  const layout = el('div', { class: 'pn-create-layout' });

  const previewSide = el('div', { class: 'pn-create-preview-side' });
  const dropZone = el('label', { class: 'pn-dropzone' });
  const fileInput = el('input', {
    type: 'file', accept: 'image/*', class: 'pn-hidden-input',
    ...(isEdit ? {} : { multiple: 'true' }),
  });

  let selectedItems = [];
  let uploadedUrl = existingPost?.image_url || null;

  const thumbStrip = el('div', { class: 'pn-multi-thumb-strip pn-hidden' });
  const multiHint = el('p', { class: 'pn-field-hint pn-multi-hint pn-hidden' },
    'Se creará una publicación por cada imagen. Puedes darle un título distinto a cada una, o dejar el mismo para todas.');
  const titleLabel = el('span', {}, 'Título (opcional)');

  function paintThumbStrip() {
    thumbStrip.innerHTML = '';
    if (selectedItems.length < 2) {
      thumbStrip.classList.add('pn-hidden');
      return;
    }
    thumbStrip.classList.remove('pn-hidden');
    selectedItems.forEach((item, i) => {
      const titleField = el('input', {
        type: 'text', class: 'pn-multi-thumb-title', placeholder: `Título de la imagen ${i + 1}`,
        value: item.customTitle || '',
      });
      titleField.addEventListener('input', () => { item.customTitle = titleField.value; });

      const tile = el('div', { class: 'pn-multi-thumb-card' }, [
        el('div', { class: 'pn-multi-thumb' }, [
          el('img', { src: item.previewUrl }),
          el('button', {
            type: 'button', class: 'pn-multi-thumb-remove',
            onClick: (e) => {
              e.preventDefault();
              selectedItems.splice(i, 1);
              paintDropzone();
            },
          }, icon('x', 12)),
        ]),
        titleField,
      ]);
      thumbStrip.appendChild(tile);
    });
  }

  function paintDropzone() {
    dropZone.innerHTML = '';
    if (selectedItems.length === 1) {
      dropZone.appendChild(el('img', { src: selectedItems[0].previewUrl, class: 'pn-dropzone-preview' }));
      dropZone.appendChild(el('span', { class: 'pn-dropzone-change' }, 'Cambiar imagen'));
    } else if (selectedItems.length > 1) {
      dropZone.appendChild(el('img', { src: selectedItems[0].previewUrl, class: 'pn-dropzone-preview' }));
      dropZone.appendChild(el('span', { class: 'pn-dropzone-change' }, `${selectedItems.length} imágenes seleccionadas · Toca para cambiar`));
    } else if (uploadedUrl) {
      dropZone.appendChild(el('img', { src: uploadedUrl, class: 'pn-dropzone-preview' }));
      dropZone.appendChild(el('span', { class: 'pn-dropzone-change' }, 'Cambiar imagen'));
    } else {
      dropZone.append(
        icon('image-plus', 36),
        el('span', {}, isEdit ? 'Toca para elegir una imagen' : 'Toca para elegir una o varias imágenes'),
        el('span', { class: 'pn-field-hint' }, 'JPG, PNG o WEBP')
      );
    }
    dropZone.appendChild(fileInput);
    paintThumbStrip();
    multiHint.classList.toggle('pn-hidden', selectedItems.length <= 1);
    titleLabel.textContent = selectedItems.length > 1 ? 'Título (opcional, por defecto para todas)' : 'Título (opcional)';
  }

  paintDropzone();

  fileInput.addEventListener('change', () => {
    const files = Array.from(fileInput.files || []);
    if (files.length === 0) return;
    const invalid = files.some(f => !f.type.startsWith('image/'));
    if (invalid) { toast('Selecciona solo archivos de imagen', 'error'); return; }

    if (isEdit) {
      selectedItems = [{ file: files[0], previewUrl: URL.createObjectURL(files[0]) }];
    } else {
      selectedItems = files.map(f => ({ file: f, previewUrl: URL.createObjectURL(f) }));
    }
    uploadedUrl = null;
    paintDropzone();
  });

  previewSide.append(dropZone, thumbStrip);

  const stockBtn = el('button', {
    type: 'button', class: 'pn-btn pn-btn-ghost pn-stock-photo-btn',
    onClick: () => showStockPhotoModal((file, previewUrl) => {
      selectedItems = [{ file, previewUrl }];
      uploadedUrl = null;
      paintDropzone();
    }),
  }, [icon('images', 15), ' Buscar imagen sin copyright']);
  previewSide.appendChild(stockBtn);

  // ---- Lado de formulario ----
  const formSide = el('div', { class: 'pn-create-form-side' });

  const titleInput = el('input', { type: 'text', class: 'pn-input', placeholder: 'Añade un título (opcional)', maxlength: '120', value: existingPost?.title || '' });
  const descInput = el('textarea', { class: 'pn-input', placeholder: 'Cuenta más sobre esta imagen', rows: '4', maxlength: '500' }, existingPost?.description || '');
  const linkInput = el('input', { type: 'url', class: 'pn-input', placeholder: 'https://ejemplo.com (opcional)', value: existingPost?.external_link || '' });
  const tagsInput = el('input', { type: 'text', class: 'pn-input', placeholder: 'diseño, minimalismo, azul (separados por coma)', value: (existingPost?.tags || []).join(', ') });

  const catSelect = el('select', { class: 'pn-input', required: 'true' });
  catSelect.appendChild(el('option', { value: '', disabled: 'true', selected: existingPost ? null : 'true' }, 'Elige una categoría'));

  const boardSelect = el('select', { class: 'pn-input' });
  boardSelect.appendChild(el('option', { value: '' }, 'No añadir a un tablero'));

  CategoriesService.fetchAll().then(cats => {
    cats.forEach(c => {
      const opt = el('option', { value: c.id }, c.label);
      if (existingPost?.category_id === c.id) opt.setAttribute('selected', 'true');
      catSelect.appendChild(opt);
    });
  });

  if (PinovaAuth.isLoggedIn()) {
    BoardsService.fetchByOwner(PinovaAuth.user.id, true).then(boards => {
      boards.forEach(b => boardSelect.appendChild(el('option', { value: b.id }, b.name)));
    });
  }

  const progressWrap = el('div', { class: 'pn-multi-progress pn-hidden' });
  const submitBtn = el('button', { type: 'submit', class: 'pn-btn pn-btn-primary pn-btn-block' }, isEdit ? 'Guardar cambios' : 'Publicar');

  const form = el('form', { class: 'pn-create-form' }, [
    multiHint,
    el('label', { class: 'pn-field' }, [titleLabel, titleInput]),
    el('label', { class: 'pn-field' }, [el('span', {}, 'Descripción'), descInput]),
    el('label', { class: 'pn-field' }, [el('span', {}, 'Categoría'), catSelect]),
    el('label', { class: 'pn-field' }, [el('span', {}, 'Etiquetas'), tagsInput]),
    el('label', { class: 'pn-field' }, [el('span', {}, 'Enlace externo'), linkInput]),
    !isEdit ? el('label', { class: 'pn-field' }, [el('span', {}, 'Tablero'), boardSelect]) : null,
    progressWrap,
    submitBtn,
  ]);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (selectedItems.length === 0 && !uploadedUrl) { toast('Añade una imagen para continuar', 'error'); return; }
    if (!catSelect.value) { toast('Elige una categoría para continuar', 'error'); return; }

    const tags = tagsInput.value.split(',').map(t => t.trim().toLowerCase()).filter(Boolean).slice(0, 10);
    const baseTitle = titleInput.value.trim() || 'Sin título';
    const basePayload = {
      description: descInput.value.trim(),
      external_link: linkInput.value.trim() || null,
      category_id: catSelect.value ? Number(catSelect.value) : null,
      tags,
    };

    submitBtn.disabled = true;

    // ---- Caso: edición o una sola imagen nueva ----
    if (isEdit || selectedItems.length <= 1) {
      submitBtn.textContent = isEdit ? 'Guardando...' : 'Publicando...';
      const singleFile = selectedItems[0]?.file || null;
      if (singleFile) VisualSearch.ensureModel();

      try {
        let imageUrl = uploadedUrl;
        let dims = { image_width: existingPost?.image_width || null, image_height: existingPost?.image_height || null };
        let visualData = {};

        if (singleFile) {
          imageUrl = await PostsService.uploadImage(singleFile, PinovaAuth.user.id);
          dims = await getImageDimensions(singleFile);
          try {
            const imgEl = await VisualSearch.loadImageElement(singleFile);
            const [embedding, phash] = await Promise.all([
              VisualSearch.getEmbedding(imgEl),
              Promise.resolve(VisualSearch.computePHash(imgEl)),
            ]);
            visualData = { embedding, phash };
          } catch { /* análisis visual opcional */ }
        }

        const payload = {
          title: baseTitle,
          image_url: imageUrl,
          image_width: dims.image_width,
          image_height: dims.image_height,
          ...basePayload,
          ...visualData,
        };

        let post;
        if (isEdit) {
          post = await PostsService.update(existingPost.id, payload);
          toast('Publicación actualizada', 'success');
        } else {
          post = await PostsService.create({ ...payload, author_id: PinovaAuth.user.id });
          if (boardSelect.value) await BoardsService.addPost(boardSelect.value, post.id, imageUrl);
          toast('Publicación creada', 'success');
        }
        PinovaRouter.navigate(`/post/${post.id}`);
      } catch (err) {
        console.error('Error al guardar publicación:', err);
        toast(err?.message || 'No se pudo guardar la publicación', 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = isEdit ? 'Guardar cambios' : 'Publicar';
      }
      return;
    }

    // ---- Caso: varias imágenes nuevas → un post por cada una ----
    VisualSearch.ensureModel();
    progressWrap.classList.remove('pn-hidden');
    progressWrap.innerHTML = '';
    const total = selectedItems.length;
    const progressLabel = el('p', { class: 'pn-muted' }, `Publicando 0 de ${total}...`);
    const progressBar = el('div', { class: 'pn-progress-bar-track' }, el('div', { class: 'pn-progress-bar-fill' }));
    progressWrap.append(progressLabel, progressBar);
    submitBtn.textContent = 'Publicando...';

    let successCount = 0;
    let firstCreatedPost = null;
    const failedTitles = [];

    for (let i = 0; i < selectedItems.length; i++) {
      const { file, customTitle } = selectedItems[i];
      const titleForThis = (customTitle || '').trim() || baseTitle;
      try {
        const imageUrl = await PostsService.uploadImage(file, PinovaAuth.user.id);
        const dims = await getImageDimensions(file);
        let visualData = {};
        try {
          const imgEl = await VisualSearch.loadImageElement(file);
          const [embedding, phash] = await Promise.all([
            VisualSearch.getEmbedding(imgEl),
            Promise.resolve(VisualSearch.computePHash(imgEl)),
          ]);
          visualData = { embedding, phash };
        } catch { /* análisis visual opcional */ }

        const payload = {
          title: titleForThis,
          image_url: imageUrl,
          image_width: dims.image_width,
          image_height: dims.image_height,
          ...basePayload,
          ...visualData,
          author_id: PinovaAuth.user.id,
        };
        const post = await PostsService.create(payload);
        if (boardSelect.value) await BoardsService.addPost(boardSelect.value, post.id, imageUrl);
        if (!firstCreatedPost) firstCreatedPost = post;
        successCount++;
      } catch (err) {
        console.error(`Error al publicar imagen ${i + 1}:`, err);
        failedTitles.push(titleForThis);
      }
      progressLabel.textContent = `Publicando ${i + 1} de ${total}...`;
      progressWrap.querySelector('.pn-progress-bar-fill').style.width = `${((i + 1) / total) * 100}%`;
    }

    if (successCount === 0) {
      toast('No se pudo publicar ninguna imagen', 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Publicar';
      return;
    }

    if (failedTitles.length > 0) {
      toast(`${successCount} de ${total} publicadas. Algunas fallaron.`, 'default');
    } else {
      toast(`${successCount} publicaciones creadas`, 'success');
    }

    if (successCount === 1 && firstCreatedPost) {
      PinovaRouter.navigate(`/post/${firstCreatedPost.id}`);
    } else {
      PinovaRouter.navigate(`/profile/me`);
    }
  });

  formSide.appendChild(form);
  layout.append(previewSide, formSide);
  wrap.appendChild(layout);
  root.appendChild(wrap);
}

function getImageDimensions(file) {
  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      resolve({ image_width: img.naturalWidth, image_height: img.naturalHeight });
      URL.revokeObjectURL(url);
    };
    img.onerror = () => resolve({ image_width: null, image_height: null });
    img.src = url;
  });
}
