// ============================================================
// PINOVA — Búsqueda por foto: modal de captura + resultados
// ============================================================

function showVisualSearchModal() {
  const overlay = el('div', { class: 'pn-modal-overlay' });

  const fileInput = el('input', {
    type: 'file', accept: 'image/*', class: 'pn-hidden-input',
  });

  const dropZone = el('label', { class: 'pn-dropzone pn-visual-search-dropzone' }, [
    icon('camera', 36),
    el('span', {}, 'Toca para tomar una foto o elegir de tu galería'),
    el('span', { class: 'pn-field-hint' }, 'Buscaremos publicaciones parecidas o iguales'),
    fileInput,
  ]);

  const box = el('div', { class: 'pn-modal-box' }, [
    el('div', { class: 'pn-modal-header' }, [
      el('h3', {}, 'Buscar con una foto'),
      el('button', { class: 'pn-modal-close', onClick: () => overlay.remove() }, icon('x', 18)),
    ]),
    dropZone,
  ]);

  overlay.appendChild(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files[0];
    if (!file) return;
    overlay.remove();
    await runVisualSearchFlow(file);
  });
}

async function runVisualSearchFlow(file) {
  const progressOverlay = el('div', { class: 'pn-modal-overlay' });
  const progressBox = el('div', { class: 'pn-confirm-box pn-visual-progress-box' }, [
    el('div', { class: 'pn-spinner' }),
    el('h3', {}, 'Analizando tu foto...'),
    el('p', {}, 'Esto puede tardar unos segundos la primera vez.'),
  ]);
  progressOverlay.appendChild(progressBox);
  document.body.appendChild(progressOverlay);

  try {
    const imgEl = await VisualSearch.loadImageElement(file);
    const [embedding, phash] = await Promise.all([
      VisualSearch.getEmbedding(imgEl),
      Promise.resolve(VisualSearch.computePHash(imgEl)),
    ]);

    const previewUrl = URL.createObjectURL(file);
    progressOverlay.remove();

    PinovaRouter.navigate('/visual-search');
    requestAnimationFrame(() => {
      renderVisualSearchResults({ previewUrl, embedding, phash });
    });
  } catch (err) {
    progressOverlay.remove();
    toast('No se pudo analizar la imagen. Intenta con otra foto.', 'error');
  }
}

function pageVisualSearch(root) {
  const wrap = el('div', { class: 'pn-page-pad', id: 'pn-visual-search-root' });
  wrap.appendChild(el('div', { class: 'pn-empty-state' }, [
    icon('camera', 44),
    el('h2', {}, 'Busca con una foto'),
    el('p', {}, 'Toma o elige una imagen para encontrar publicaciones iguales o parecidas.'),
    el('button', { class: 'pn-btn pn-btn-primary', onClick: () => showVisualSearchModal() }, [icon('camera', 16), ' Tomar o elegir foto']),
  ]));
  root.appendChild(wrap);
}

async function renderVisualSearchResults({ previewUrl, embedding, phash }) {
  const root = qs('#pn-visual-search-root') || qs('.pn-page-content');
  if (!root) return;
  root.innerHTML = '';

  const header = el('div', { class: 'pn-visual-results-header' }, [
    el('img', { src: previewUrl, class: 'pn-visual-results-preview' }),
    el('div', {}, [
      el('h1', { class: 'pn-page-title' }, 'Resultados visuales'),
      el('p', { class: 'pn-muted' }, 'Basado en la foto que compartiste'),
    ]),
    el('button', { class: 'pn-btn pn-btn-ghost', onClick: () => showVisualSearchModal() }, [icon('camera', 15), ' Probar otra foto']),
  ]);
  root.appendChild(header);

  const exactSection = el('section', { class: 'pn-explore-section' }, [
    el('h2', {}, 'Coincidencias exactas'),
    el('div', { class: 'pn-spinner-wrap' }, el('div', { class: 'pn-spinner' })),
  ]);
  const similarSection = el('section', { class: 'pn-explore-section' }, [
    el('h2', {}, 'Imágenes parecidas'),
    el('div', { class: 'pn-spinner-wrap' }, el('div', { class: 'pn-spinner' })),
  ]);
  root.append(exactSection, similarSection);

  try {
    const exactMatches = await VisualSearchService.searchByPHash(phash, 8);
    const exactPosts = await VisualSearchService.hydratePosts(exactMatches);
    exactSection.querySelector('.pn-spinner-wrap').remove();
    if (exactPosts.length === 0) {
      exactSection.appendChild(el('p', { class: 'pn-muted' }, 'No encontramos ninguna publicación idéntica.'));
    } else {
      const grid = el('div', { class: 'pn-masonry' });
      exactPosts.forEach((p, i) => {
        const card = renderPostCard(p);
        card.classList.add('pn-card-enter');
        card.style.animationDelay = (i % 12) * 30 + 'ms';
        grid.appendChild(card);
      });
      exactSection.appendChild(grid);
    }
  } catch {
    exactSection.querySelector('.pn-spinner-wrap').remove();
    exactSection.appendChild(el('p', { class: 'pn-muted' }, 'No se pudo completar esta búsqueda.'));
  }

  try {
    const similarRows = await VisualSearchService.searchByEmbedding(embedding, 0.35, 24);
    const similarPosts = await VisualSearchService.hydratePosts(similarRows);
    similarSection.querySelector('.pn-spinner-wrap').remove();
    if (similarPosts.length === 0) {
      similarSection.appendChild(el('p', { class: 'pn-muted' }, 'No encontramos publicaciones visualmente parecidas todavía.'));
    } else {
      const grid = el('div', { class: 'pn-masonry' });
      similarPosts.forEach((p, i) => {
        const card = renderPostCard(p);
        card.classList.add('pn-card-enter');
        card.style.animationDelay = (i % 12) * 30 + 'ms';
        grid.appendChild(card);
      });
      similarSection.appendChild(grid);
    }
  } catch {
    similarSection.querySelector('.pn-spinner-wrap').remove();
    similarSection.appendChild(el('p', { class: 'pn-muted' }, 'No se pudo completar esta búsqueda. La búsqueda visual requiere que existan publicaciones ya analizadas.'));
  }
}
