// ============================================================
// PINOVA — Página: Guardados (acceso rápido)
// ============================================================

function pageSaved(root) {
  const wrap = el('div', { class: 'pn-page-pad' });
  wrap.appendChild(el('h1', { class: 'pn-page-title' }, 'Tus guardados'));
  root.appendChild(wrap);

  createMasonryGrid({
    container: wrap,
    fetchPage: async (page) => (page === 0 ? await InteractionsService.fetchSavedByUser(PinovaAuth.user.id) : []),
    emptyMessage: 'No has guardado nada todavía. Explora y toca "Guardar" en lo que te inspire.',
    emptyIcon: 'bookmark',
  });
}
