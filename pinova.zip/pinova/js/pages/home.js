// ============================================================
// PINOVA — Página: Inicio (feed principal)
// ============================================================

function pageHome(root) {
  const wrap = el('div', { class: 'pn-page-pad' });

  const catBar = el('div', { class: 'pn-category-bar' });
  CategoriesService.fetchAll().then(cats => {
    const allBtn = el('button', { class: 'pn-chip pn-chip-active' }, 'Para ti');
    catBar.appendChild(allBtn);
    cats.forEach(c => {
      const chip = el('button', { class: 'pn-chip' }, c.label);
      chip.addEventListener('click', () => PinovaRouter.navigate(`/explore?cat=${c.slug}`));
      catBar.appendChild(chip);
    });
    refreshIcons();
  });
  wrap.appendChild(catBar);

  root.appendChild(wrap);

  createMasonryGrid({
    container: wrap,
    fetchPage: (page) => PostsService.fetchFeed({ page }),
    emptyMessage: 'Aún no hay publicaciones. ¡Sé la primera persona en compartir algo!',
    emptyIcon: 'sparkles',
  });
}
