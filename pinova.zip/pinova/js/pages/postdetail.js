// ============================================================
// PINOVA — Página: Detalle de publicación
// ============================================================

async function pagePostDetail(root, params) {
  const wrap = el('div', { class: 'pn-post-detail-wrap' });
  wrap.appendChild(el('div', { class: 'pn-spinner-wrap pn-spinner-full' }, el('div', { class: 'pn-spinner' })));
  root.appendChild(wrap);

  let post;
  try {
    post = await PostsService.fetchById(params.id);
  } catch {
    wrap.innerHTML = '';
    wrap.appendChild(el('div', { class: 'pn-empty-state' }, [
      icon('image-off', 44),
      el('h2', {}, 'Publicación no encontrada'),
      el('button', { class: 'pn-btn pn-btn-primary', onClick: () => PinovaRouter.navigate('/') }, 'Volver al inicio'),
    ]));
    return;
  }

  wrap.innerHTML = '';

  const backBtn = el('button', { class: 'pn-back-btn pn-detail-back', onClick: () => (history.length > 1 ? history.back() : PinovaRouter.navigate('/')) }, icon('arrow-left', 20));

  const detailCard = el('div', { class: 'pn-detail-card' });

  const imgSide = el('div', { class: 'pn-detail-img-side' }, [
    el('img', { src: post.image_url, alt: post.title, class: 'pn-detail-img' }),
  ]);
  attachLongPress(imgSide, post);

  const infoSide = el('div', { class: 'pn-detail-info-side' });

  const actionsRow = el('div', { class: 'pn-detail-actions' });

  const saveBtn = el('button', { class: 'pn-btn pn-btn-primary' }, [icon('bookmark', 17), ' Guardar']);
  const likeBtn = el('button', { class: 'pn-btn pn-btn-ghost' }, [icon('heart', 17), ` ${formatCount(post.like_count)}`]);
  const shareBtn = el('button', { class: 'pn-btn pn-btn-ghost' }, [icon('share-2', 17), ' Compartir']);
  const downloadBtn = el('button', { class: 'pn-btn pn-btn-ghost' }, [icon('download', 17), ' Descargar']);
  downloadBtn.addEventListener('click', () => {
    const safeName = (post.title || 'pinova-imagen').toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 50);
    downloadImage(post.image_url, `${safeName}.jpg`);
  });

  saveBtn.addEventListener('click', async () => {
    if (!PinovaAuth.requireAuth()) return;
    const saved = saveBtn.dataset.saved === 'true';
    saveBtn.disabled = true;
    const nowSaved = await InteractionsService.toggleSave(PinovaAuth.user.id, post.id, saved);
    saveBtn.dataset.saved = String(nowSaved);
    saveBtn.innerHTML = '';
    saveBtn.appendChild(icon(nowSaved ? 'bookmark-check' : 'bookmark', 17));
    saveBtn.append(nowSaved ? ' Guardado' : ' Guardar');
    saveBtn.classList.toggle('pn-btn-primary', !nowSaved);
    saveBtn.classList.toggle('pn-btn-saved', nowSaved);
    saveBtn.disabled = false;
    toast(nowSaved ? 'Publicación guardada' : 'Se quitó de guardados', 'success');
  });

  likeBtn.addEventListener('click', async () => {
    if (!PinovaAuth.requireAuth()) return;
    const liked = likeBtn.dataset.liked === 'true';
    likeBtn.disabled = true;
    const nowLiked = await InteractionsService.toggleLike(PinovaAuth.user.id, post.id, liked);
    likeBtn.dataset.liked = String(nowLiked);
    post.like_count += nowLiked ? 1 : -1;
    likeBtn.innerHTML = '';
    likeBtn.appendChild(icon('heart', 17));
    likeBtn.append(` ${formatCount(post.like_count)}`);
    likeBtn.classList.toggle('pn-liked', nowLiked);
    likeBtn.disabled = false;
  });

  shareBtn.addEventListener('click', () => {
    navigator.clipboard?.writeText(location.origin + location.pathname + `#/post/${post.id}`);
    toast('Enlace copiado al portapapeles', 'success');
  });

  actionsRow.append(saveBtn, likeBtn, downloadBtn, shareBtn);

  if (PinovaAuth.user?.id === post.author_id) {
    const menuBtn = el('button', { class: 'pn-icon-btn', onClick: () => showPostMenu(post, menuBtn) }, icon('more-horizontal', 18));
    actionsRow.appendChild(menuBtn);
  }

  const authorRow = el('a', { href: `#/profile/${post.author?.username}`, class: 'pn-detail-author-row' }, [
    renderAvatar(post.author, 44),
    el('div', {}, [
      el('span', { class: 'pn-detail-author-name' }, post.author?.display_name),
      el('span', { class: 'pn-detail-author-handle' }, '@' + post.author?.username),
    ]),
  ]);

  const title = el('h1', { class: 'pn-detail-title' }, post.title);
  const description = post.description ? el('p', { class: 'pn-detail-description' }, post.description) : null;

  const meta = el('div', { class: 'pn-detail-meta-row' }, [
    post.category ? el('a', { href: `#/explore?cat=${post.category.slug}`, class: 'pn-chip pn-chip-small' }, post.category.label) : null,
    ...(post.tags || []).map(t => el('span', { class: 'pn-tag' }, '#' + t)),
  ]);

  if (post.external_link) {
    meta.appendChild(el('a', { href: post.external_link, target: '_blank', rel: 'noopener noreferrer', class: 'pn-external-link' }, [
      icon('external-link', 14), ' Ver enlace original',
    ]));
  }

  const savesInfo = el('p', { class: 'pn-detail-saves-info' }, [icon('bookmark', 14), ` ${formatCount(post.save_count)} guardados`]);

  infoSide.append(actionsRow, authorRow, title, meta, description, savesInfo);

  const commentsSection = el('div', { class: 'pn-comments-section' });
  infoSide.appendChild(commentsSection);

  detailCard.append(imgSide, infoSide);
  wrap.append(backBtn, detailCard);

  const relatedSection = el('section', { class: 'pn-related-section' }, [
    el('h2', {}, 'Más como esto'),
    el('div', { id: 'pn-related-grid' }),
  ]);
  wrap.appendChild(relatedSection);

  // estado inicial saved/liked
  if (PinovaAuth.isLoggedIn()) {
    const [saved, liked] = await Promise.all([
      InteractionsService.isSaved(PinovaAuth.user.id, post.id),
      InteractionsService.isLiked(PinovaAuth.user.id, post.id),
    ]);
    saveBtn.dataset.saved = String(saved);
    likeBtn.dataset.liked = String(liked);
    if (saved) {
      saveBtn.innerHTML = ''; saveBtn.appendChild(icon('bookmark-check', 17)); saveBtn.append(' Guardado');
      saveBtn.classList.remove('pn-btn-primary'); saveBtn.classList.add('pn-btn-saved');
    }
    if (liked) { likeBtn.classList.add('pn-liked'); }
  }

  renderComments(commentsSection, post);

  createMasonryGrid({
    container: relatedSection.querySelector('#pn-related-grid'),
    fetchPage: async (page) => {
      if (page > 0) return [];
      return await PostsService.fetchRelated(post);
    },
    emptyMessage: 'No hay publicaciones relacionadas aún.',
  });
}

function renderComments(container, post) {
  container.appendChild(el('h3', { class: 'pn-comments-title' }, `Comentarios (${post.comment_count})`));

  const listEl = el('div', { class: 'pn-comments-list' }, el('div', { class: 'pn-spinner-wrap' }, el('div', { class: 'pn-spinner' })));
  container.appendChild(listEl);

  if (PinovaAuth.isLoggedIn()) {
    const input = el('textarea', { class: 'pn-input pn-comment-input', placeholder: 'Añade un comentario...', rows: '2', maxlength: '500' });
    const submitBtn = el('button', { class: 'pn-btn pn-btn-primary' }, 'Publicar');
    const form = el('form', { class: 'pn-comment-form' }, [input, submitBtn]);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = input.value.trim();
      if (!body) return;
      submitBtn.disabled = true;
      try {
        const comment = await InteractionsService.addComment(post.id, PinovaAuth.user.id, body);
        const emptyMsg = qs('.pn-comments-empty', listEl);
        if (emptyMsg) emptyMsg.remove();
        listEl.prepend(renderCommentRow(comment, post));
        input.value = '';
      } catch {
        toast('No se pudo publicar el comentario', 'error');
      } finally {
        submitBtn.disabled = false;
      }
    });
    container.appendChild(form);
  } else {
    container.appendChild(el('p', { class: 'pn-muted' }, [
      el('a', { href: '#/login' }, 'Inicia sesión'), ' para comentar.',
    ]));
  }

  InteractionsService.fetchComments(post.id).then(comments => {
    listEl.innerHTML = '';
    if (comments.length === 0) {
      listEl.appendChild(el('p', { class: 'pn-muted pn-comments-empty' }, 'Sé la primera persona en comentar.'));
      return;
    }
    comments.reverse().forEach(c => listEl.appendChild(renderCommentRow(c, post)));
  });
}

function renderCommentRow(comment, post) {
  const isOwner = PinovaAuth.user && (PinovaAuth.user.id === comment.author_id || PinovaAuth.user.id === post.author_id);
  const row = el('div', { class: 'pn-comment-row' }, [
    renderAvatar(comment.author, 32),
    el('div', { class: 'pn-comment-body' }, [
      el('div', { class: 'pn-comment-head' }, [
        el('a', { href: `#/profile/${comment.author?.username}`, class: 'pn-comment-author' }, comment.author?.display_name),
        el('span', { class: 'pn-comment-time' }, timeAgo(comment.created_at)),
      ]),
      el('p', {}, comment.body),
    ]),
  ]);
  if (isOwner) {
    const delBtn = el('button', {
      class: 'pn-comment-delete',
      onClick: async () => {
        const ok = await confirmDialog({ title: 'Eliminar comentario', message: '¿Seguro que quieres eliminar este comentario?' });
        if (!ok) return;
        try {
          await InteractionsService.removeComment(comment.id);
          row.remove();
        } catch {
          toast('No se pudo eliminar el comentario', 'error');
        }
      },
    }, icon('x', 14));
    row.appendChild(delBtn);
  }
  return row;
}
