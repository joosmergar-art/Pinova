// ============================================================
// PINOVA — Punto de entrada de la aplicación
// ============================================================

(async function bootPinova() {
  const appRoot = document.getElementById('pn-app');

  const navbar = renderNavbar();
  const pageContent = el('main', { class: 'pn-page-content' });
  const bottomNav = renderBottomNav();

  appRoot.append(navbar, pageContent, bottomNav);

  PinovaRouter.init(pageContent);

  PinovaRouter.add('/', (params, query) => pageHome(pageContent));
  PinovaRouter.add('/explore', (params, query) => pageExplore(pageContent, params, query));
  PinovaRouter.add('/search', (params, query) => pageSearch(pageContent, params, query));
  PinovaRouter.add('/visual-search', () => pageVisualSearch(pageContent));
  PinovaRouter.add('/post/:id', (params) => pagePostDetail(pageContent, params));
  PinovaRouter.add('/profile/:username', (params) => pageProfile(pageContent, params));
  PinovaRouter.add('/board/:id', (params) => pageBoard(pageContent, params));

  PinovaRouter.add('/login', () => pageLogin(pageContent));
  PinovaRouter.add('/signup', () => pageSignup(pageContent));
  PinovaRouter.add('/forgot-password', () => pageForgotPassword(pageContent));
  PinovaRouter.add('/reset-password', () => pageResetPassword(pageContent));

  PinovaRouter.add('/create', (params) => pageCreatePost(pageContent, params), { auth: true });
  PinovaRouter.add('/edit/:id', (params) => pageCreatePost(pageContent, params), { auth: true });
  PinovaRouter.add('/saved', () => pageSaved(pageContent), { auth: true });

  PinovaRouter.add('/privacy', () => pagePrivacy(pageContent));
  PinovaRouter.add('/terms', () => pageTerms(pageContent));

  await PinovaAuth.init();

  PinovaRouter.resolve();
  updateActiveNav();

  // Re-renderizar la ruta actual cuando cambia el estado de auth,
  // para reflejar botones de seguir/editar/etc. correctamente.
  let firstAuthEvent = true;
  PinovaAuth.onChange(() => {
    if (firstAuthEvent) { firstAuthEvent = false; return; }
    PinovaRouter.resolve();
  });
})();
