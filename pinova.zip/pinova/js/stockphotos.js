// ============================================================
// PINOVA — Banco de imágenes libres de copyright (Pexels)
// ============================================================

const StockPhotosService = {
  async search(query, page = 1, perPage = 24) {
    const url = `https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&page=${page}&per_page=${perPage}`;
    const res = await fetch(url, {
      headers: { Authorization: PINOVA_CONFIG.pexelsApiKey },
    });
    if (!res.ok) throw new Error('pexels_error');
    const data = await res.json();
    return (data.photos || []).map(p => ({
      id: p.id,
      thumbUrl: p.src.medium,
      fullUrl: p.src.large2x || p.src.original,
      width: p.width,
      height: p.height,
      photographer: p.photographer,
      photographerUrl: p.photographer_url,
      alt: p.alt || query,
    }));
  },

  async curated(page = 1, perPage = 24) {
    const url = `https://api.pexels.com/v1/curated?page=${page}&per_page=${perPage}`;
    const res = await fetch(url, {
      headers: { Authorization: PINOVA_CONFIG.pexelsApiKey },
    });
    if (!res.ok) throw new Error('pexels_error');
    const data = await res.json();
    return (data.photos || []).map(p => ({
      id: p.id,
      thumbUrl: p.src.medium,
      fullUrl: p.src.large2x || p.src.original,
      width: p.width,
      height: p.height,
      photographer: p.photographer,
      photographerUrl: p.photographer_url,
      alt: p.alt || 'Foto libre de derechos',
    }));
  },

  /**
   * Descarga una foto de Pexels y la devuelve como File, lista para
   * subirse al Storage de Pinova como si fuera una imagen propia.
   */
  async toFile(photo) {
    const res = await fetch(photo.fullUrl);
    const blob = await res.blob();
    const ext = (blob.type.split('/')[1] || 'jpg').replace('jpeg', 'jpg');
    return new File([blob], `pexels-${photo.id}.${ext}`, { type: blob.type });
  },
};
