// ============================================================
// PINOVA — Búsqueda visual: embeddings MobileNet + pHash
// Todo corre en el navegador, sin servicios externos de pago.
// ============================================================

const VisualSearch = {
  _model: null,
  _loadingPromise: null,
  _scriptsLoadingPromise: null,

  _loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.onload = resolve;
      s.onerror = () => reject(new Error(`No se pudo cargar ${src}`));
      document.head.appendChild(s);
    });
  },

  async ensureScripts() {
    if (window.tf && window.mobilenet) return;
    if (this._scriptsLoadingPromise) return this._scriptsLoadingPromise;
    this._scriptsLoadingPromise = (async () => {
      if (!window.tf) {
        await this._loadScript('https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.20.0/dist/tf.min.js');
      }
      if (!window.mobilenet) {
        await this._loadScript('https://cdn.jsdelivr.net/npm/@tensorflow-models/mobilenet@2.1.1/dist/mobilenet.min.js');
      }
    })();
    return this._scriptsLoadingPromise;
  },

  async ensureModel() {
    if (this._model) return this._model;
    if (this._loadingPromise) return this._loadingPromise;
    this._loadingPromise = (async () => {
      await this.ensureScripts();
      // mobilenet expone window.mobilenet tras cargar el script UMD
      this._model = await window.mobilenet.load({ version: 2, alpha: 1.0 });
      return this._model;
    })();
    return this._loadingPromise;
  },

  /**
   * Genera un embedding (array de 1024 números) a partir de un elemento <img> o <video>/<canvas>.
   */
  async getEmbedding(imgEl) {
    const model = await this.ensureModel();
    const activation = model.infer(imgEl, true); // true = capa de embedding (1024-d) en vez de clasificación
    const arr = await activation.data();
    activation.dispose();
    return Array.from(arr);
  },

  /**
   * Calcula un hash perceptual (pHash) de 64 bits a partir de un elemento <img>.
   * Sirve para detectar duplicados/casi-duplicados exactos de forma barata.
   */
  computePHash(imgEl) {
    const size = 32;
    const smallSize = 8;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(imgEl, 0, 0, size, size);
    const imageData = ctx.getImageData(0, 0, size, size).data;

    // escala de grises
    const gray = new Float64Array(size * size);
    for (let i = 0; i < size * size; i++) {
      const r = imageData[i * 4], g = imageData[i * 4 + 1], b = imageData[i * 4 + 2];
      gray[i] = 0.299 * r + 0.587 * g + 0.114 * b;
    }

    // DCT 2D simplificada, quedándonos con el bloque de baja frecuencia (8x8)
    const dct = applyDCT2D(gray, size);
    const block = [];
    for (let y = 0; y < smallSize; y++) {
      for (let x = 0; x < smallSize; x++) {
        block.push(dct[y * size + x]);
      }
    }
    // excluir el término DC (índice 0) para el promedio
    const avg = block.slice(1).reduce((a, b) => a + b, 0) / (block.length - 1);
    let hash = '';
    for (let i = 0; i < block.length; i++) {
      hash += block[i] > avg ? '1' : '0';
    }
    return hash; // string binario de 64 caracteres
  },

  hammingDistance(hashA, hashB) {
    if (!hashA || !hashB || hashA.length !== hashB.length) return 64;
    let dist = 0;
    for (let i = 0; i < hashA.length; i++) {
      if (hashA[i] !== hashB[i]) dist++;
    }
    return dist;
  },

  cosineSimilarity(a, b) {
    let dot = 0, normA = 0, normB = 0;
    for (let i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    return dot / (Math.sqrt(normA) * Math.sqrt(normB));
  },

  /**
   * Carga una imagen desde un File/Blob y la devuelve como <img> ya decodificado,
   * listo para usarse con getEmbedding/computePHash.
   */
  async loadImageElement(fileOrBlob) {
    const url = URL.createObjectURL(fileOrBlob);
    const img = new Image();
    img.crossOrigin = 'anonymous';
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
      img.src = url;
    });
    URL.revokeObjectURL(url);
    return img;
  },

  /**
   * Carga una imagen desde una URL remota (con crossOrigin) para poder generarle
   * embedding/pHash en el momento (usado al indexar posts existentes si hiciera falta).
   */
  async loadImageFromUrl(url) {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
      img.src = url;
    });
    return img;
  },
};

// DCT-II 2D básica (separable), suficiente para pHash de 32x32
function applyDCT2D(data, size) {
  const temp = new Float64Array(size * size);
  const out = new Float64Array(size * size);

  // DCT por filas
  for (let y = 0; y < size; y++) {
    const row = data.subarray(y * size, y * size + size);
    const rowOut = dct1D(row, size);
    temp.set(rowOut, y * size);
  }
  // DCT por columnas
  const col = new Float64Array(size);
  for (let x = 0; x < size; x++) {
    for (let y = 0; y < size; y++) col[y] = temp[y * size + x];
    const colOut = dct1D(col, size);
    for (let y = 0; y < size; y++) out[y * size + x] = colOut[y];
  }
  return out;
}

function dct1D(vec, N) {
  const out = new Float64Array(N);
  for (let k = 0; k < N; k++) {
    let sum = 0;
    for (let n = 0; n < N; n++) {
      sum += vec[n] * Math.cos((Math.PI / N) * (n + 0.5) * k);
    }
    const ck = k === 0 ? Math.sqrt(1 / N) : Math.sqrt(2 / N);
    out[k] = ck * sum;
  }
  return out;
}
