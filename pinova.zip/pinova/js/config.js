// ============================================================
// PINOVA — Configuración global
// ============================================================

const PINOVA_CONFIG = {
  supabaseUrl: 'https://zbxyuqnzbjtrbvrbazuf.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpieHl1cW56Ymp0cmJ2cmJhenVmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYxMzQxODUsImV4cCI6MjEwMTcxMDE4NX0.78I_JqQPNB0rmuVuaYjAItXuZToKOihZs5Q_P7Si4jE',
  storageBucket: 'pinova-images',
  appName: 'Pinova',
  postsPerPage: 24,
  pexelsApiKey: 'L9IfwoYVTGrUEUNvyHUNBRmiaP6kLIvdLICOs5mzHx8Cv9cr98QMH0Bi',
};

const supabaseClient = window.supabase.createClient(
  PINOVA_CONFIG.supabaseUrl,
  PINOVA_CONFIG.supabaseAnonKey
);
